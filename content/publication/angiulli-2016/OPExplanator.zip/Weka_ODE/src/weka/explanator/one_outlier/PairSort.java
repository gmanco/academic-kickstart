package weka.explanator.one_outlier;

public class PairSort {

	private int[] index;
	private double[] val;

	public PairSort(double[] value, int[] index) {
		this.val = value;
		this.index = index;

	}

	public double[] getEl() {
		return val;

	}

	public int[] getIndex() {
		return index;

	}



}
