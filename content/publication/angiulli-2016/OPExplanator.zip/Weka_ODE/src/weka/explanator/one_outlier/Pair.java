package weka.explanator.one_outlier;

public class Pair {
	
	double val;
	double val2;
	
	int index;
	
	public Pair(double val, int index){
		this.val=val;
		this.index=index;
	}
	
	public Pair(double min, double max){
		this.val=min;
		this.val2=max;
	}
	
	public int getIndex(){
		return this.index;
		
	}
	
	public double getValue(){
		return this.val;
		
	}
	
	
	public double getValue2(){
		return this.val2;
		
	}
	
	public String toString(){
		return "["+val+", "+ val2+"]";
	}
}
