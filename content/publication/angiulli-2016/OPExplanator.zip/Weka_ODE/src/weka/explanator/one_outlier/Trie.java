package weka.explanator.one_outlier;

import java.util.Iterator;

public class Trie {

	Nodo root = null;

	boolean[] curr_expl; // M

	private Stack stack; // M

	int M; // numero attributi

	private int num_car = 0;

	private Nodo curr_stack;

	boolean sinistra = true;

	public Trie(int M) {
		this.M = M;
		stack = new Stack(M + 1);
		curr_expl = new boolean[M];
	}

	class Nodo {
		ListConcatenata lista;
		Nodo left;
		Nodo right;

		public int size() {
			return lista.size();
		}

		@Override
		public String toString() {
			return "{lista: " + lista + " - size: " + size() + "}";
		}
	}

	public void insert2(boolean[] e) {
		
		if (root == null) {
			// inserisci sempre prim a sinistra
			root = new Nodo();
			root.lista = new ListConcatenata();
			Nodo sx = new Nodo();
			sx.lista = new ListConcatenata().addExpl(e);
			root.left = sx;
			root.right = null;

		} else {
			if (root.left == null) {
				Nodo sx = new Nodo();
				sx.lista = new ListConcatenata().addExpl(e);
				root.left = sx;
			} else {
				if (!aggiungi(root.left, e, 0)) {
					if (root.right == null) {
						Nodo dx = new Nodo();
						dx.lista = new ListConcatenata().addExpl(e);
						root.right = dx;
					} else {
						aggiungi(root.right, e, 0);
					}
				}
			}
		}
	}

	private boolean aggiungi(Nodo corrente, boolean[] expl, int start) {
		SplitTrie s = corrente.lista.confronta(expl, start);
		if (s == null)
			return false;

		if (s.getListaFiglio() != null) {

			Nodo nodoSinistro = new Nodo();
			nodoSinistro.lista = s.getListaFiglio();
			nodoSinistro.left = corrente.left;
			nodoSinistro.right = corrente.right;
			Nodo nodoDestro = new Nodo();
			nodoDestro.lista = new ListConcatenata().addExpl(expl,
					s.getIndice(), expl.length);

			nodoDestro.left = null;
			nodoDestro.right = null;
			corrente.left = nodoSinistro;
			corrente.right = nodoDestro;

			return true;

		}

		if (!aggiungi(corrente.left, expl, s.getIndice()))
			if (!aggiungi(corrente.right, expl, s.getIndice()))
				return false;

		return true;

	}

	public boolean contains(boolean[] e) {

		if (root == null)
			return false;

		if (root.left == null)
			return false;

		if (cerca(root.left, e, 0) == e.length)
			return true;

		if (root.right == null)
			return false;

		if (cerca(root.right, e, 0) == e.length)
			return true;
		return false;
	}

	private int cerca(Nodo corrente, boolean[] expl, int begin) {

		if (corrente == null)
			return 0;

		int count = corrente.lista.countMatch(expl, begin);

		if (count <= 0)
			return 0;

		if ((expl.length - count) == begin) {
			// System.out.println("FINITOOOOO");
			return count;
		}

		return count + cerca(corrente.left, expl, begin + count)
				+ cerca(corrente.right, expl, begin + count);

	}

	public static String stampaArray(int[] explanation) {

		StringBuilder sb = new StringBuilder();

		sb.append("[ ");
		for (int i = 0; i < explanation.length; i++) {
			sb.append(explanation[i] + " ");
		}
		sb.append("]");
		return sb.toString();
	}

	public static String stampaArray(boolean[] explanation) {

		StringBuilder sb = new StringBuilder();

		sb.append("[ ");
		for (int i = 0; i < explanation.length; i++) {
			sb.append(explanation[i] + " ");
		}
		sb.append("]");
		return sb.toString();
	}

	private void visitaAnticipata(Nodo radice, String s) {
		if (radice != null) {
			System.out.println(s + radice.lista);
			// System.out.println("\nsx");
			visitaAnticipata(radice.left, s + "\t");
			// System.out.println("\ndx");
			visitaAnticipata(radice.right, s + "\t");
		}
	}// visitaAnticipata

	public void visita() {
		visitaAnticipata(root, "");
		System.out.println();

	}

	public Trie reset() {
		root = null;
		return this;
	}

	public int size() {
		return size(root);
	}// size

	private int size(Nodo radice) {
		if (radice == null)
			return 0;
		return 1 + size(radice.left) + size(radice.right);
	}// size



	public String stampaSpiegazione(int[] e) {

		StringBuilder sb = new StringBuilder();

		sb.append("{ ");
		for (int i = 0; i < e.length; i++) {
			if (e[i] == 1)
				sb.append((i + 1) + " ");
		}
		sb.append("}");
		return sb.toString();
	}

	public boolean[] get() {

		Nodo succ_stack;

		if (root == null) {
			// System.out.println("root == null");
			return null;
		}
		if (stack.size() == 0) {

			// � la prima get che faccio
			curr_stack = root;
			stack.push(curr_stack);

			while (curr_stack.left != null) {

				curr_stack = curr_stack.left;
				this.stack.push(curr_stack);
				// copia valore nell'array che bisogna resttuire
				ListConcatenata l = curr_stack.lista;
				// System.out.println("\t\t aggiungo " + l);
				Iterator<Boolean> it = l.iterator();
				// int valore;
				while (it.hasNext()) {
					boolean cur = it.next();
					// valore = 0;
					// if (cur)
					// valore = 1;
					curr_expl[num_car] = cur;
					num_car++;
				}

			}// while left

		} else {

			// System.out.println("\t\t Stack: "+stack);

			succ_stack = (Nodo) stack.pop();
			// ELIMINARE I CARATTERI COPIATI
			num_car = num_car - succ_stack.size();
			// System.out.println("\t\t Prima volta... Elimino "+succ_stack +
			// " lascio "+num_car+" elementi");

			curr_stack = (Nodo) stack.getTopElement();

			do {
				// System.out.println("\t\t Stack: "+stack);

				if (succ_stack == curr_stack.left) {
					if (curr_stack.right != null) {

						curr_stack = curr_stack.right;

						while (curr_stack != null) {
							this.stack.push(curr_stack);
							// copia valore nell'array che bisogna resttuire
							ListConcatenata l = curr_stack.lista;
							// System.out.println("\t\t aggiungo " + l);
							Iterator<Boolean> it = l.iterator();
							// int valore;
							while (it.hasNext()) {
								boolean cur = it.next();
								// valore = 0;
								// if (cur)
								// valore = 1;
								curr_expl[num_car] = cur;
								num_car++;
							}

							curr_stack = curr_stack.left;

						}
						return curr_expl;
					} else
						// SOLO LA ROOT pu� avere figlio destro null
						// System.out.println("\t\t Solo la root pu� avere il figlio destro a null... Esco per questo!!!");
						return null;
				}

				succ_stack = (Nodo) stack.pop();
				// ELIMINARE I CARATTERI COPIATI
				num_car = num_car - succ_stack.size();
				// System.out.println("\t\t Elimino "+succ_stack +
				// " lascio "+num_car+" elementi");

				curr_stack = (Nodo) stack.getTopElement();
				// System.out.println(curr_stack);

			} while (curr_stack != null);

			// System.out.println("\t\t Esco...");
			return null;
		}

		return curr_expl;
	}

	public Stack getStack() {
		return stack;
	}

	public static void main(String[] args) {
		Trie t = new Trie(4);
//		int[][] expls = { { 0, 0, 0, 0 }, { 0, 0, 0, 1 }, { 0, 0, 1, 0 },
//				{ 0, 0, 1, 1 }, { 0, 1, 0, 0 }, { 0, 1, 0, 1 }, { 0, 1, 1, 0 },
//				{ 0, 1, 1, 1 }, { 1, 0, 0, 0 }, { 1, 0, 0, 1 }, { 1, 0, 1, 0 },
//				{ 1, 0, 1, 1 }, { 1, 1, 0, 0 }, { 1, 1, 0, 1 }, { 1, 1, 1, 0 },
//				{ 1, 1, 1, 1 } };
//	

		System.out.println("Printing tree...\n");
		t.visita();


		System.out.println("***********************");
		boolean[] a;
		while ((a = t.get()) != null)
			System.out.println(stampaArray(a));

		System.out
				.println("secnda volta...........................................");

		boolean[] b;
		while ((b = t.get()) != null)
			System.out.println(stampaArray(b));

	}

	public void clearStack() {
	
		this.stack.clear();
	}

}
