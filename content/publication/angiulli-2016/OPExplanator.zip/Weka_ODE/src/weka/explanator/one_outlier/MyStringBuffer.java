package weka.explanator.one_outlier;

public final class MyStringBuffer {

	public void append(String string) {
		System.out.print(string);
	
	}
	
}
