package weka.explanator.one_outlier;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;

import weka.core.Capabilities;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Option;
import weka.core.OptionHandler;
import weka.core.Utils;
import weka.explanator.Explanator;

/**
 * OPD Depth - Classe per la GUI Explanator
 * 
 * @author Marialuisa
 * 
 */
public class OPD_Depth implements Explanator, OptionHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Num. Instances
	 */
	private int N;

	/**
	 * Num. Attributes
	 */
	private int M;

	/**
	 * Matrice elementi clusterizzati
	 */
	private int[][] cluster;

	private double[][] dataset;

	private MyHeap topk;
	private List<Result> result;

	private StringBuffer p1 = new StringBuffer();

	private StringBuffer p2 = new StringBuffer();

	private StringBuffer error_s = new StringBuffer();

	/**
	 * Parametri algo
	 */

	private int out;
	private double threshold;
	private int levels;
	private int k;
	private double out_thres;

	private boolean v;

	private boolean clu;

	private double time_p1;

	private double time_p2;

	// indice di riga da copiare
	int[] id;

	private int[] eid;

	private int[] id_heap;

	private String nomeFCluster;

	private BitSet A;
	private BitSet B;

	private boolean error;

	private int out_stampa;

	private int count_computeOut;
	private int count_underTrheshold;

	private boolean technique;

	private int count_out_threshold;

	public OPD_Depth() {
		if (v) {
			p1.append("\n===== Cluster =====\n");
			p2.append("\n===== Search Outlier ====\n");
		}
		error_s.append("\n===== Error ====\n");
		resetOptions();
	}

	@Override
	public void build(Instances data) throws Exception {

		System.out.println("build");
		this.M = data.numAttributes();
		this.N = data.numInstances();

		System.out.println("\t\t N: " + N + " - M: " + M);

		this.cluster = new int[N][M];

		this.dataset = new double[N][M];

		// TODO
		this.nomeFCluster = data.relationName() + "_CJ";

		for (int i = 0; i < N; i++) {
			Instance m = data.instance(i);
			double[] h = m.toDoubleArray();
			for (int j = 0; j < M; j++) {
				dataset[i][j] = h[j];
			}
		}

		this.A = new BitSet(N);
		this.B = new BitSet(N);

		this.id = new int[N];
		// L'outlier far� sempre parte delle righe selezionate da una
		// spiegazione
		for (int i = 0; i < N; i++)
			id[i] = i;
		this.eid = new int[M];

		if (technique) {
			// soglia oulierness omega
			this.result = new LinkedList<Result>();

		} else {

			// topk
			this.id_heap = new int[M];

			for (int i = 0; i < id_heap.length; i++) {
				id_heap[i] = -1;
			}

			topk = new MyHeap(k, MyHeap.MIN_HEAP, id_heap);

		}

		if (clu == true) {
			clusterDiscretize();
			findProperty(out, threshold, levels, k);
		} else {
			leggiCluster(nomeFCluster);
			findProperty(out, threshold, levels, k);
		}

	}

	public int getOut() {
		return this.out;
	}

	public double getThreshold() {
		return this.threshold;
	}

	public double getThreshold_Out() {
		return this.out_thres;
	}

	public void setThreshold_Out(double omega) {
		this.out_thres = omega;
	}

	public int getLevels() {
		return this.levels;
	}

	public int getK() {
		return this.k;
	}

	public void setOut(int id) {
		this.out = id;
	}

	public void setThreshold(double t) {
		this.threshold = t;
	}

	public void setLevels(int l) {
		this.levels = l;
	}

	public void setK(int k) {
		this.k = k;
	}

	public boolean getVerbose() {
		return this.v;
	}

	public boolean getDoCluster() {
		return this.clu;
	}

	public void setVerbose(boolean b) {
		this.v = b;
	}

	public boolean getTechnique() {
		return this.technique;
	}

	public void setTechnique(boolean b) {
		this.technique = b;
	}

	public void setDoCluster(boolean b) {
		this.clu = b;
	}

	// Passo 1
	private void clusterDiscretize() throws Exception {


		/*this.cluster = new int[N][M];

		long start, elapsed, time = 0;

		EM[] em = new EM[M];
		Remove filter = new Remove();

		for (int i = 0; i < M; i++) {
			em[i] = new EM();
			em[i].setNumClusters(-1);

			filter.setInputFormat(data);
			String range;
			if (i == 0)
				range = "2-last";
			else if (i == M - 2)
				range = "first-" + (M - 2) + ",last";
			else if (i == M - 1)
				range = "first-" + (M - 1);
			else if (i == 1)
				range = "first,3-last";
			else
				range = "first-" + i + "," + (i + 2) + "-last";

			String[] options = new String[2];
			options[0] = "-R";
			options[1] = range;

			filter.setOptions(options);
			if (v)
				p1.append("\nWorking on range: " + range + "... ");

			start = System.currentTimeMillis();
			Instances filtered = filter.useFilter(data, filter);
			em[i].buildClusterer(filtered);
			elapsed = System.currentTimeMillis() - start;
			time += elapsed;

			if (v)
				p1.append("done [" + (elapsed / 1000.0) + "secs, "
						+ em[i].numberOfClusters() + " intervals]");

			for (int j = 0; j < N; j++)
				cluster[j][i] = em[i].clusterInstance(filtered.instance(j));
		}

		PrintWriter p = new PrintWriter(data.relationName() + "_CJ" + ".txt");

		this.nomeFCluster = data.relationName() + "_CJ";
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++)
				p.print(cluster[i][j] + " ");
			p.println();
		}
		p.flush();
		p.close();

		p1.append("\n\nTime elapsed: " + (time / 1000.0) + " secs\n");
		this.time_p1 = (time / 1000.0);
		p1.append("\n===================================================\n");*/
		
		this.cluster = new int[N][M];

		double alpha = 0.1; //1e-4;

		long start, elapsed, time = 0;

		EMDiscretizer[] em = new EMDiscretizer[M];

		for (int i = 0; i < M; i++) {
			em[i] = new EMDiscretizer(i,alpha);

			System.out.print("Working on attribute: " + i + " ...");

			if (v)
				p1.append("\nWorking on attribute: " + i + "... ");

			start = System.currentTimeMillis();
			long start1 = System.currentTimeMillis();
			em[i].buildClusterer(this.dataset);
			long elapsed2 = System.currentTimeMillis() - start1;
			elapsed = System.currentTimeMillis() - start;
			time += elapsed;

			if(v){
				System.out.println("done [" + (elapsed / 1000.0) + "secs (clustering " + (elapsed2 / 1000.0) + "secs), "
						+ em[i].numberOfClusters() + " intervals]");
				System.out.println(em[i]);
				p1.append("done [" + (elapsed / 1000.0) + "secs (clustering " +
(elapsed2 / 1000.0) + "secs), "
						+ em[i].numberOfClusters() + " intervals]");
			}

			for (int j = 0; j < N; j++)
				cluster[j][i] = em[i].clusterInstance(dataset[j][i]);
		}

		// System.out.println("Time elapsed: " + (time / 1000.0) + "secs");

		PrintWriter p = new PrintWriter(N+"_"+M+"_CJ" + ".txt");

		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++)
				p.print(cluster[i][j] + " ");
			p.println();
		}
		p.flush();
		p.close();

		p1.append("\n\nTime elapsed: " + (time / 1000.0) + " secs\n");
		this.time_p1 = (time / 1000.0);
		p1.append("\n===================================================\n");

	}

	// passo 2

	/**
	 * ok
	 * 
	 * @param id
	 * @param treshold
	 * @param livelli
	 * @param k
	 */
	public void findProperty(int out, double treshold, int levels, int k) {

		// System.out.println("Find property....");
		long start = System.currentTimeMillis();

		int id_out = out - 1;
		// double[] out_ds = new double[M];
		// double[] riga1_ds = new double[M];
		// for (int i = 0; i < M; i++) {
		// out_ds[i] = this.dataset[id_out][i];
		// riga1_ds[i] = this.dataset[0][i];
		// }
		//
		// // inverto le righe
		// for (int i = 0; i < M; i++) {
		// this.dataset[0][i] = out_ds[i];
		// this.dataset[id_out][i] = riga1_ds[i];
		// }
		//
		// int[] out_cluster = new int[M];
		// int[] riga1_cluster = new int[M];
		// for (int i = 0; i < M; i++) {
		// out_cluster[i] = this.cluster[id_out][i];
		// riga1_cluster[i] = this.cluster[0][i];
		// }
		//
		// // inverto le righe
		// for (int i = 0; i < M; i++) {
		// this.cluster[0][i] = out_cluster[i];
		// this.cluster[id_out][i] = riga1_cluster[i];
		// }
		//
		// // prima posizione: indice 0

		this.out_stampa = out;

		double[] firstRow_temp = dataset[0];
		dataset[0] = dataset[id_out];
		dataset[id_out] = firstRow_temp;

		int[] firstRow_tempCluster = cluster[0];
		cluster[0] = cluster[id_out];
		cluster[id_out] = firstRow_tempCluster;

		id_out = 0;
		this.out = id_out;

		double min_n = Math.ceil(N * treshold);

		// this.topk = new Matrix(k, M + 2);

		boolean[] explanation = new boolean[M];

		for (int attr = 0; attr < M; attr++) {

			if (technique == true) {
				// omega

				if (v) {
					p2.append("\n\n\t\t Property: " + (attr + 1));
				}
				search_omega(explanation, id_out, min_n, 0, levels, attr, N);
			} else {
				// topk
				if (v) {
					p2.append("\n\n\t\t Property: " + (attr + 1));
				}
				search_topK(explanation, id_out, min_n, 0, levels, attr, N);
			}

		}

		long elapsed = System.currentTimeMillis() - start;
		this.time_p2 = (elapsed / 1000.0);
		if (v) {
			p2.append("\n\n\nTime elapsed: " + time_p2 + " secs\n");
			p2.append("==================================================");
		}

		// System.out.println(printResult(pq));

		// System.out.println("Time part 1: " + time_p1);
		// System.out.println("Time part 2: " + time_p2);

		// System.out.println("\n\n " + printResult());

	}

	/**
	 * 
	 * @param topk
	 * @param explanation
	 * @param id_out
	 * @param I
	 * @param min_n
	 * @param level
	 * @param levels
	 * @param attr
	 * @return
	 */
	public void search_omega(boolean[] explanation, int id_out, double min_n,
			int level, int levels, int attr, int sexpl) {

		if (v) {
			p2.append("\nSearch with explanation: ");
			p2.append(stampaSpiegazione(explanation));
			// p2.append(stampaArray(explanation));
		}
		int s = select2(explanation, sexpl);

		if (s > min_n - 1) {

			double out = computeOutlierness(id_out, attr, s);

			if (v) {
				// p2.append("\n\t\t Property: " + (attr + 1));
				p2.append(".... OUT: " + Utility.arrotonda(out, 2));
			}

			if (out >= out_thres) {
				// topk.insert(out, attr, explanation);
				update_result(attr, explanation, out);
				this.count_out_threshold++;

				if (v) {
					p2.append("\n\t\t Upper outlierness Threshold:  "
							+ Utility.arrotonda(out, 2) + " >= " + out_thres);
				}
			} else {
				if (level < levels) {
					int index = find(explanation, true);
					if (index == -1)// non ci sono 1
						index = -1;

					boolean[] e = new boolean[explanation.length];
					for (int i = 0; i < M; i++) {
						e[i] = explanation[i];
					}
					for (int m = index + 1; m < M; m++) {
						if (m != attr) {
							e[m] = true;
							search_omega(e, id_out, min_n, level + 1, levels,
									attr, s);
							e[m] = false;
						}
					}// for

				}// level<levels
			}

		} else {
			// System.out.println("Under Threshold");

			this.count_underTrheshold++;
			if (v)
				p2.append(" --> Under Support Threshold!!!");

		}

	}// search

	public void search_topK(boolean[] explanation, int id_out, double min_n,
			int level, int levels, int attr, int sexpl) {

		if (v) {
			p2.append("\n Search with explanation: ");
			p2.append(stampaSpiegazione(explanation));
			// p2.append(stampaArray(explanation));
		}
		int s = select2(explanation, sexpl);

		if (s > min_n - 1) {

			double out = computeOutlierness(id_out, attr, s);

			update_topk(attr, explanation, out, level);

			if (v) {
				// p2.append("\n\t\t Property: " + (attr + 1));
				p2.append(".... OUT: " + Utility.arrotonda(out, 2));
			}

			if (level < levels) {
				int index = find(explanation, true);
				if (index == -1)// non ci sono 1
					index = -1;

				boolean[] e = new boolean[explanation.length];
				for (int i = 0; i < M; i++) {
					e[i] = explanation[i];
				}
				for (int m = index + 1; m < M; m++) {
					if (m != attr) {
						e[m] = true;
						search_topK(e, id_out, min_n, level + 1, levels, attr,
								s);
						e[m] = false;
					}
				}// for

			}// level<levels

		} else {
			// System.out.println("Under Threshold");

			this.count_underTrheshold++;
			if (v)
				p2.append(" --> Under Support Threshold!!!");

		}

	}// search

	private void update_result(int attr, boolean[] explanation, double out2) {

		this.result.add(new Result(out2, attr, explanation));

	}

	private int select2(boolean[] e, int sexpl) {

		// System.out.print("SELECT: " + stampaSpiegazione(e) + " - " +
		// " sexpl: " + sexpl);
		int e_size = 0;

		// eid=attributi della spiegazione
		for (int i = 0; i < e.length; i++)
			if (e[i]) {
				eid[e_size] = i;
				e_size++;
			}

		if (e_size == 0) {
			// s = N;
			return N;
		}

		int s_corr = 1;

		int r, c = eid[e_size - 1];

		int temp;

		// System.out.println("Spiegazione: " + e_size + " " +
		// stampaArray(eid));

		for (int i = 1; i < sexpl; i++) {// N; i++) {
			r = id[i];

			if (cluster[r][c] == cluster[0][c]) {
				temp = id[s_corr];
				id[s_corr] = id[i];
				id[i] = temp;
				s_corr++;
			}
		}

		return s_corr;

	}// select

	/**
	 * 
	 * @param id_out
	 * @param matrice_creata
	 * @param attr
	 * @return
	 */
	public double computeOutlierness(int id_out, int attr, int s) {

		this.count_computeOut++;

		double out_result = 0;

		double[] d = new double[s];
		for (int riga = 0; riga < s; riga++) {
			d[riga] = dataset[id[riga]][attr];

		}

		if (Utility.standardDeviation2(d) == 0) {
			return out_result = 0;
		}

		double[] f = estimatePDF(d);// , m);

		// stampaVettore(f,"Funzione f: ");

		double[] G = Utility.cumulata(s);

		PairSort p = Utility.sort__2(f);

		int[] index = p.getIndex();

		int sid = -1;
		for (int i = 0; i < index.length; i++) {
			if (index[i] == id_out)
				sid = i;

		}

		if (sid == s - 1) {
			return out_result = 0;
		}

		out_result = compute_value_out(sid, s, G, p.getEl());

		// long end = System.currentTimeMillis() - start;
		// System.out.println("Compute outlienress --> " + (end / 1000.0));

		return out_result;

	}

	/**
	 * 
	 * @param attr
	 * @param explanation
	 * @param out
	 * @param l
	 */

	public void update_topk(int attr, boolean[] explanation, double out, int l) {

		topk.insertGeneric(out, attr, explanation, l);

	}

	/**
	 * ok
	 * 
	 * @param data
	 * @return
	 */

	public double[] estimatePDF(double[] data) {// , Matrix m_data) {

		// long start = System.currentTimeMillis();
		int n = data.length;
		double h = 1.06 * Utility.standardDeviation2(data)
				* Math.pow(n, -(double) 1 / 5);

		double[] weight = new double[n];
		for (int i = 0; i < weight.length; i++) {
			weight[i] = 1;

		}

		double[] f = computePDF(data, weight, h);

		double geo_mean = Utility.mediaGeometrica(f);

		// weight=sqrt(fmean./f);
		// weight[i]=fmean/f[i]

		// weight = update_weight(geo_mean, f, weight)
		for (int i = 0; i < weight.length; i++) {
			weight[i] = Math.sqrt((double) geo_mean / f[i]);
		}

		// long end = System.currentTimeMillis() - start;
		// System.out.println("estimate PDF -->" + (end / 1000.0));

		return f;
	}

	public double[] computePDF(double[] data, double[] weight, double h) {

		// long start = System.currentTimeMillis();

		int n = data.length;
		// System.out.println("\n--------------> N " + n);

		double[] weight_op = new double[weight.length];
		for (int i = 0; i < weight.length; i++) {
			weight_op[i] = weight[i] * (double) h / 2;
		}

		PairSort lower = Utility.sort__2(Utility.minus(data, weight_op));
		PairSort upper = Utility.sort__2(Utility.plus(data, weight_op));

		int[] lw = lower.getIndex();
		int[] up = upper.getIndex();

		double[] f = new double[n];
		double sum = 0;

		int l_i, u_i;

		for (int i = 0; i < n; i++) {

			A.reset();
			B.reset();

			l_i = Utility.ricerca2(data[i], lower.getEl(), false);
			u_i = Utility.ricerca2(data[i], upper.getEl(), true);

			for (int j = 0; j <= l_i; j++) {
				A.set(lw[j]);
			}

			for (int j = u_i; j < n; j++) {
				B.set(up[j]);
			}

			A.intersect(B);

			sum = 0;

			for (int j = 0; j < N; j++) {
				if (A.get(j)) {
					sum += (double) 1 / weight[j];
				}
			}

			f[i] = (double) sum / (n * h);

		}

		// long end1 = System.currentTimeMillis() - start1;
		// System.out.println("\nfor  -->" + (end1 / 1000.0));

		// long end = System.currentTimeMillis() - start;
		// System.out.println("Compute PDF  -->" + (end / 1000.0));
		return f;
	}

	/**
	 * ok
	 * 
	 * @param sid
	 * @param n
	 * @param g
	 * @param el
	 * @return
	 */

	public double compute_value_out(int sid, int n, double[] g, double[] el) {

		// out=sum(diff(fs(sid:n)).*(2-G(sid+1:n)-G(sid:n-1))/2);

		double[] fs = Utility.subArrayD2(el, sid, n - 1);

		double[] g1 = Utility.subArrayD2(g, sid + 1, n - 1);

		double[] g2 = Utility.subArrayD2(g, sid, n - 2);

		double[] diff = Utility.diff(fs);

		double out_value = 0;
		for (int i = 0; i < diff.length; i++) {
			out_value += diff[i] * ((2 - g1[i] - g2[i]) / 2);
		}

		out_value = (1 - Math.exp(-out_value)) / (1 + Math.exp(-out_value));
		// return Utility.arrotonda(out_value,6);
		return out_value;

	}

	/**
	 * Trova in explanation l'ultio indice di number se non c� -1
	 * 
	 * @param explanation
	 * @param number
	 * @return
	 */
	private int find(boolean[] explanation, boolean number) {
		int index = -1;
		for (int i = 0; i < explanation.length; i++) {
			if (explanation[i] == number)
				index = i;
		}
		return index;
	}

	// passo 2

	public String toString() {
		// return stampaMatrice(cluster, "Matrice Cluster") + " \n \n "
		// + stampaDataset(dataset, "Dataset") + "\n \n "
		// + printMatrix(this.result, "Matrice Risultato: ");

		if (error)
			return error_s.toString();
		else {
			String s1 = p1.toString();
			String s2 = p2.toString();
			String result;
			if (technique)
				result = printResult_Omega();
			else
				result = printResult_TopK();
			String res = s1 + "\n " + s2 + " \n\n === Result === \n" + result;

			return res;
		}

	}

	public static String stampaArray(int[] explanation) {
		StringBuilder sb = new StringBuilder();

		sb.append("[ ");
		for (int i = 0; i < explanation.length; i++) {
			sb.append(explanation[i] + " ");
		}
		sb.append("]");
		return sb.toString();
	}

	/**
	 * PANNELLO PARAMETR. SEZIONE ABOUT.. NN CI SONO CAPABILITIES!!!
	 */

	public Pair find_intervallo_spiegazione(int id_out, int prop) {
		int clu = this.cluster[id_out][prop];
		double[] v = new double[N];
		int count = 0;
		for (int i = 0; i < N; i++) {
			if (this.cluster[i][prop] == clu) {
				v[count] = dataset[i][prop];
				count++;
			}
		}

		double min = v[0], max = v[0];
		for (int i = 1; i < count; i++) {
			if (v[i] < min)
				min = v[i];
			if (v[i] > max)
				max = v[i];
		}

		return new Pair(min, max);
	}

	public String printResult_TopK() {
		StringBuilder sb = new StringBuilder();
		sb.append("ALGORITHM: Depth algorithm  - Top K Results\n");

		sb.append("DATASET:\n");
		sb.append("\t Instances: " + N + "\n");
		sb.append("\t Attributes: " + M + "\n");

		sb.append("\nPARAMETERS: \n");
		sb.append("\t Id_out: " + (this.out_stampa) + "\n");
		sb.append("\t Threshold: " + this.threshold + "\n");
		sb.append("\t Levels: " + this.levels + "\n");
		sb.append("\t K: " + this.k + "\n");

		sb.append("\nTIMES:\n");
		sb.append("\t Time part 1: " + this.time_p1);
		sb.append("\n\t Time part 2: " + this.time_p2);
		sb.append("\n\t Total Time: " + (this.time_p2 + this.time_p1));

		sb.append("\nCOUNT:\n");
		sb.append(" # Compute Outlierness: " + this.count_computeOut + "\n");
		sb.append(" # Under threshold dataset: " + this.count_underTrheshold
				+ "\n");

		sb.append("\n\nRESULT: \n");

		Result[] rr = topk.getOrderedArray();

		for (int i = 0; i < rr.length; i++) {
			// System.out.println(rr[i]);
			Result r = rr[i];
			sb.append("\tValue: " + Utility.arrotonda(r.getOut(), 4));
			sb.append("\t Property: " + Integer.toString((r.getAttr() + 1)));
			sb.append("\t Explanation: ");
			sb.append("{ ");
			for (int j = 0; j < r.getExpl().length; j++) {
				if (r.getExpl()[j]) {
					sb.append("[" + (j + 1) + "");
					sb.append(" @"
							+ find_intervallo_spiegazione(out, r.getAttr())
							+ "] ");

				}

			}
			sb.append("}");
			sb.append("\n");
		}

		sb.append("\n\n");

		return sb.toString();

	}

	public String printResult_Omega() {
		StringBuilder sb = new StringBuilder();
		sb.append("ALGORITHM: Depth algorithm -  Omega - Outlierness Threshold\n");

		sb.append("DATASET:\n");
		sb.append("\t Instances: " + N + "\n");
		sb.append("\t Attributes: " + M + "\n");

		sb.append("\nPARAMETERS: \n");
		sb.append("\t Id_out: " + (this.out_stampa) + "\n");
		sb.append("\t Threshold: " + this.threshold + "\n");
		sb.append("\t Levels: " + this.levels + "\n");
		sb.append("\t Out_thres: " + this.out_thres + "\n");

		sb.append("\nTIMES:\n");
		sb.append("\t Time part 1: " + this.time_p1);
		sb.append("\n\t Time part 2: " + this.time_p2);

		sb.append("\nCOUNT:\n");
		sb.append(" # Compute Outlierness: " + this.count_computeOut + "\n");
		sb.append(" # Under threshold dataset: " + this.count_underTrheshold
				+ "\n");
		sb.append(" # Upper outlierness threshold:  "
				+ this.count_out_threshold + "\n");

		sb.append("\n\nRESULT: \n");

		Iterator<Result> rr = result.iterator();

		while (rr.hasNext()) {
			// System.out.println(rr[i]);
			Result r = rr.next();
			sb.append("\tValue: " + Utility.arrotonda(r.getOut(), 4));
			sb.append("\t Property: " + Integer.toString((r.getAttr() + 1)));
			sb.append("\t Explanation: ");
			sb.append("{ ");
			for (int j = 0; j < r.getExpl().length; j++) {
				if (r.getExpl()[j]) {
					sb.append("[" + (j + 1) + "");
					sb.append(" @"
							+ find_intervallo_spiegazione(out, r.getAttr())
							+ "] ");

				}

			}
			sb.append("}");
			sb.append("\n");
		}

		sb.append("\n\n");

		return sb.toString();

	}

	/**
	 * Returns a string describing this clusterer
	 * 
	 * @return a description of the evaluator suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	public String globalInfo() {
		return "OPD - Outlying Property Detector.\n\n";
		// + "EM assigns a probability distribution to each instance which "

		// "indicates the probability of it belonging to each of the clusters. "
		// +
		// "EM can decide how many clusters to create by cross validation, or you "
		// + "may specify apriori how many clusters to generate.\n\n"
		// +
		// "The cross validation performed to determine the number of clusters "
		// + "is done in the following steps:\n"
		// + "1. the number of clusters is set to 1\n"
		// + "2. the training set is split randomly into 10 folds.\n"
		// +
		// "3. EM is performed 10 times using the 10 folds the usual CV way.\n"
		// + "4. the loglikelihood is averaged over all 10 results.\n"
		// +
		// "5. if loglikelihood has increased the number of clusters is increased "
		// + "by 1 and the program continues at step 2. \n\n"
		// + "The number of folds is fixed to 10, as long as the number of "
		// +
		// "instances in the training set is not smaller 10. If this is the case "
		// + "the number of folds is set equal to the number of instances.";
	}

	/**********************************************************************
	 * OptionHandler Interface
	 ********************************************************************** 
	 */

	/**
	 * List Option: id_out, threshold, levels, k
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Enumeration listOptions() {

		// Option(String description, String name, int numArguments, String
		// synopsis)

		Vector result = new Vector();

		result.addElement(new Option(
				"\t technique: topk or outlierness threshold", "TEC", 0, "-TEC"));
		result.addElement(new Option("\tverbose", "V", 0, "-V"));
		result.addElement(new Option("\tflag", "F", 0, "-F"));

		result.addElement(new Option("\tId outlier object", "O", 1, "-O <num>"));
		result.addElement(new Option("\t Support Threshold", "T", 1, "-T <num>"));
		result.addElement(new Option("\t Threshold Oulierness", "OM", 1,
				"-OM <num>"));

		result.addElement(new Option("\tLevels", "L", 1, "-L <num>"));

		result.addElement(new Option("\tK", "K", 1, "-K <num>"));

		// verbose

		return result.elements();

	}

	@Override
	public void setOptions(String[] options) throws Exception {
		resetOptions();

		this.setVerbose(Utils.getFlag("V", options));
		this.setTechnique(Utils.getFlag("TEC", options));
		this.setDoCluster(Utils.getFlag("F", options));

		/**
		 * Parametri: o,threshold,levels,k
		 */
		String optionString = Utils.getOption("O", options);
		if (optionString.length() > 0) {
			this.setOut(Integer.parseInt(optionString));
		}

		optionString = Utils.getOption("T", options);
		if (optionString.length() > 0) {
			this.setThreshold(Double.parseDouble(optionString));
		}

		optionString = Utils.getOption("OM", options);
		if (optionString.length() > 0) {
			this.setThreshold_Out(Double.parseDouble(optionString));
		}

		optionString = Utils.getOption("L", options);
		if (optionString.length() > 0) {
			this.setLevels(Integer.parseInt(optionString));
		}

		optionString = Utils.getOption("K", options);
		if (optionString.length() > 0) {
			this.setK(Integer.parseInt(optionString));
		}

	}

	@Override
	public String[] getOptions() {
		Vector<String> result;
		result = new Vector<String>();
		if (!technique)
			result.add("-technique: TOP_K");
		else
			result.add("-tecnique: OMEGA");
		result.add("-O");
		result.add("" + out);
		result.add("-T");
		result.add("" + threshold);
		result.add("-L");
		result.add("" + levels);
		if (!technique) {
			result.add("-K");
			result.add("" + k);
		} else {
			result.add("-OM");
			result.add("" + out_thres);
		}
		if (v)
			result.add("-V");
		return (String[]) result.toArray(new String[result.size()]);

	}

	@Override
	public Capabilities getCapabilities() {

		return null;
	}

	public void leggiCluster(String nome) throws Exception {
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(nome));
			String text;
			int i = 0, j;
			StringTokenizer st;
			while ((text = br.readLine()) != null) {
				st = new StringTokenizer(text);
				j = 0;
				while (st.hasMoreElements()) {
					this.cluster[i][j] = Integer.parseInt((String) st
							.nextElement());
					j++;
				}
				i++;
			}
			br.close();
		} catch (FileNotFoundException e) {
			clusterDiscretize();
		}

	}

	protected void resetOptions() {

		// tecnica=false --> topk
		// else --> omega
		this.technique = false;

		out = 5;
		threshold = 0.2;
		levels = 3;

		k = 5;

		out_thres = 0.8;

		v = true;
		clu = true;

	}

	public String stampaSpiegazione(boolean[] e) {
		StringBuilder sb = new StringBuilder();

		sb.append("{ ");
		for (int i = 0; i < e.length; i++) {
			if (e[i])
				sb.append((i + 1) + " ");
		}
		sb.append("}");
		return sb.toString();
	}

}
