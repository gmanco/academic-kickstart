package weka.explanator.one_outlier;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.PriorityQueue;


public class EMDiscretizer  {
	class Border implements Comparable<Border>{
		double key;
		int position;
		public Border(double i, int j) {
			key = i;
			position = j;
		}
		@Override
		public int compareTo(Border o) {
			return Double.compare(o.key, key);
		}
		public String toString(){
			return "("+key+","+position+")";
		}
		
	}

	double alpha; 
	double minprec;
	
	double   cumsquares[];
	double   cumsum[];
	int n;
	
	PriorityQueue<Border> positions;
	ArrayList<Border> intervals;
	double limits[];
	
	double[] borders;
	
	
	//TODO:fix the data structure to be kept sorted 
	
	int attIndex; 

	
	public String toString(){
		String res = "]-Infy,";
		
		for (int i = 0; i < borders.length; i++){
			res += borders[i] + "[\n["+borders[i] + ","; 
		}
		
		res +=  "Infty[";
		
		
		
		return res;
	}

	public static void main(String[] argv) {
		double teemp[][] = {
				{3},
				{5},
				{9},
				{10},
				{11},
				{31},
				{35},
				{70},
				{71},
				{72}
		};
		

		EMDiscretizer em = new EMDiscretizer(0,0.5);

		em.buildClusterer(teemp);
		
		  System.out.println("done ["	+ em.numberOfClusters() + " intervals]");
		  System.out.println(em);

		
		
	}


	public EMDiscretizer(int index,double a) {
		this.alpha = a; 
		attIndex = index;
		intervals = new ArrayList<Border>();

	}

	public void buildClusterer(double[][] t) {
		try {
			init(t,attIndex);
			
			double oldVal = getInitialPostLog();
			
			boolean stop = false; 
			while (!stop && !positions.isEmpty()) {

				Border splitPoint = positions.remove();
				
				intervals.add(splitPoint);
				Collections.sort(intervals, new Comparator<Border>(){
					@Override
					public int compare(Border o1, Border o2) {
						return Double.compare(o1.position, o2.position);
					}
					
				});				
				int index = intervals.indexOf(splitPoint);
				//TODO: the insertion should be kept ordered already
				
				
				double val = getPosteriorLog(index,oldVal);	
				
//				System.out.println(oldVal + " -> " + val);
				if (val < oldVal){
					oldVal = val;
					
				}else {
					stop = true;
					intervals.remove(splitPoint);
				}
				
			}
			
			
			// TODO: recover intervals from cumsum using intervals;
			borders = new double[intervals.size()-2];
			
			for (int i = 0 ;i < borders.length; i++)
				borders[i] = limits[intervals.get(i+1).position-1];
			
			limits = null; 
			positions = null;
			cumsquares = cumsum = null;
			intervals = null;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	private double getInitialPostLog() {			
		double currSQval = cumsquares[n]/n;
		double currval = cumsum[n]/n;
		currval *= currval;
	
//		return n*Math.log((currSQval - currval)) + alpha*Math.log(n);

		return n*Math.log((currSQval - currval)+1) + alpha*Math.log(n);

		
		//		return currSQval - currval + alpha*Math.log(n);
	}


	private double getPosteriorLog(int index,double oldVal) {
		int prev, curr, post;
					
		prev = intervals.get(index-1).position;
		curr = intervals.get(index).position;
		post = intervals.get(index+1).position;
				
		double currSQval = (cumsquares[post-1] -cumsquares[prev-1])/(post-prev);
		double currval = (cumsum[post-1] -cumsum[prev-1])/(post-prev);
		currval *= currval;
		
		double newSQvalpre = (cumsquares[curr-1] -cumsquares[prev-1])/(curr-prev);
		double newvalpre =  (cumsum[curr-1] -cumsum[prev-1])/(curr-prev);
		newvalpre *= newvalpre;
		double newSQvalpost = (cumsquares[post-1] -cumsquares[curr-1])/(post-curr);
		double newvalpost = (cumsum[post-1] -cumsum[curr-1])/(post-curr);
		newvalpost *= newvalpost;
		
//		double newVal = oldVal - (currSQval - currval) + (newSQvalpre - newvalpre) + (newSQvalpost - newvalpost);
		
/*
		double currsigma = currSQval - currval;
		if (currsigma < minprec)
			currsigma = minprec;
		double newsigma = newSQvalpre - newvalpre;
		if (newsigma < minprec)
			newsigma = minprec;
		double postsigma = newSQvalpost - newvalpost;
		if (postsigma < minprec)
			postsigma = minprec;

		
		double newVal = oldVal - (post-prev)*Math.log(currsigma) 
				+ (curr-prev)*Math.log(newsigma) 
				+(post-curr)*Math.log(postsigma);

/*		*/
/*		*/
		double currsigma = currSQval - currval;
		double newsigma = newSQvalpre - newvalpre;
		double postsigma = newSQvalpost - newvalpost;
		
		double newVal = oldVal - (post-prev)*Math.log(currsigma + 1) 
				+ (curr-prev)*Math.log(newsigma + 1) 
				+(post-curr)*Math.log(postsigma + 1);
/* */
		
		newVal  +=  alpha*Math.log(n);
		
		return newVal;
	}



	private void init(double[][] t, int attIndex) {
		n = t.length;
		this.minprec = Math.min(1e-6,1.0/n);
		cumsquares = new double[n+2];
		cumsum = new double[n+2];
		limits = new double[n];
		
		for (int i = 0; i < n; i++)
			limits[i]= t[i][attIndex];
		
		Arrays.sort(limits);

		if (n>0){
			positions = new PriorityQueue<Border>();

			
			cumsum[0] = cumsquares[0] = 0;
			
			
			for (int i=1; i < n+1; i++){
				cumsum[i] = cumsum[i-1] + limits[i-1];
				cumsquares[i] = cumsquares[i-1] + limits[i-1]*limits[i-1];
				
				if (i < n)
					positions.add(new Border(limits[i] - limits[i-1],i+1));
			}
			
			cumsum[n+1] = cumsum[n];
			cumsquares[n+1] = cumsquares[n];
			
		}
		// fake elements to avoid checks on the index
		intervals.add(new Border(0,0));
		intervals.add(new Border(0,1));
		intervals.add(new Border(0,n+1));
	}


	public int clusterInstance(double  val) {
		int i; 
		
		for (i = 0; i < borders.length  && borders[i] <= val; i++);
			
		return i;
	}


	public int numberOfClusters() {
		if (borders != null)
			return borders.length+1;
		else return 0;
	}
}