package weka.explanator;

import java.io.Serializable;

import weka.core.Capabilities;
import weka.core.Instances;

public interface Explanator extends Serializable {
	

	  void build(Instances data) throws Exception;
	  
	  Capabilities getCapabilities();
	  
	  

}
