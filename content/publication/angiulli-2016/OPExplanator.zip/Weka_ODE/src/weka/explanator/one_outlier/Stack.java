package weka.explanator.one_outlier;

public class Stack {

	private Object[] stack;

	//puntatore al posto vacante.
	private int top = 0;
	
	//dimensione massima dello stack
	private int n; 

	public Stack(int n) {
		stack = new Object[n];
		this.n=n;
	}

	Object pop() {
		
		if (top == 0)
			return null;
		Object result = stack[top - 1];
		top--;

		return result;

	}

	
	public int getN() {
		return n;
	}
	void push(Object o) {

		stack[top] = o;
		top++;


	}

	public int size() {
		return top;
	}

	/*
	 * Restutuisce l'lelemento in testa senza rimuoverlo dalla struttura
	 * 
	 */
	public Object getTopElement() {
		if(top==0)
			return null;
		return stack[top - 1];
	}

	
	/*
	 * Svuota lo stack
	 */
	public void clear(){
		top=0;
	}//clear

	
	@Override
	public String toString() {
		// TODO Auto-generated method stub

		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for (int i = 0; i <top; i++) {
			sb.append(stack[i] + " ");
		}
		sb.append("]");
		return sb.toString();
	}


}
