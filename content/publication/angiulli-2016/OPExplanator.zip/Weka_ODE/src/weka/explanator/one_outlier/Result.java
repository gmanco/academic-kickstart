package weka.explanator.one_outlier;

public class Result {
	
	
	private int attr;
	private boolean[] e;
	private double out;
	private int level;

	public Result(int attr,boolean[] ex) {

		this.attr = attr;
		this.e = new boolean[ex.length];
		for (int i = 0; i < ex.length; i++) {
			this.e[i]=ex[i];
		}

	}
	

	public Result(int exlength) {
		e = new boolean[exlength];
	}


	public Result(double out, int attr, boolean[] ex) {
		// TODO Auto-generated constructor stub
		this.out=out;
		this.attr = attr;
		this.e = new boolean[ex.length];
		for (int i = 0; i < ex.length; i++) {
			this.e[i]=ex[i];
		}
	}


	public int getAttr(){
		return this.attr;
	}
	
	public int getLevel(){
		return level;
	}
	
	public boolean[] getExpl(){
		return this.e;
	}


	
	public String toString(){
		return "[out: " + out + "- Prop: " + (attr+1)+" - Explanation: "+ stampaArray() + "]";
		
	}
	
	public double getOut(){
		return out;
	}
	
	public String stampaArray() {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder();

//		sb.append("[ ");
//		for (int i = 0; i < e.length; i++) {
//			sb.append(e[i] + " ");
//		}
//		sb.append("] ");//---> ");
		sb.append("{ ");
		for (int i = 0; i < e.length; i++) {
			if(e[i])
				sb.append((i+1)+ " ");
		}
		sb.append("}");
		return sb.toString();
	}


	public void setAttr(int p) {
		this.attr = p;
	}

	public void setOut(double key){
		this.out=key;
	}

	public void setExpl(boolean[] e2, int l) {
		this.level = l;
	
		
		for(int i=0; i<e.length; i++)
			this.e[i] = e2[i];
	}


}
