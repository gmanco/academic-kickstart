package weka.explanator.one_outlier;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;

import weka.core.Capabilities;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Option;
import weka.core.OptionHandler;
import weka.core.Utils;
import weka.explanator.Explanator;

/**
 * OPD Livelli - strategia Apriori
 * @author Marialuisa
 *
 */
public class OPD_Levels_Main implements Explanator, OptionHandler {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Num. Instances
	 */
	private int N;

	/**
	 * Num. Attributes
	 */
	private int M;

	/**
	 * Matrice elementi clusterizzati
	 */
	private int[][] cluster;

	private double[][] dataset;

	private MyHeap topk;

	private MyStringBuffer p1 = new MyStringBuffer();

	private MyStringBuffer p2 = new MyStringBuffer();

	private MyStringBuffer error_s = new MyStringBuffer();

	private boolean[] attr_apriori;

	/**
	 * Parametri algo
	 */

	private int out;
	private double sigma;
	private int levels;
	private int k;
	private double omega;

	private boolean v;

	private boolean clu;

	private double time_p1;

	private double time_p2;

	// indice di riga da copiare
	int[] id;

	// contatore di righe
	int s = 0;

	private int[] eid;

	private int[] id_heap;

	private String nomeFCluster;

	private BitSet A;
	private BitSet B;

	private boolean error;

	private boolean[] expl_vuota;

	private int count_computeOut;
	private int count_underTrheshold;

	private boolean tecnica;

	private List<Result> result;

	private int out_stampa;

	private int count_out_threshold;

	private boolean[] a_new;

	public OPD_Levels_Main(String nomeFile, boolean doCluster)
			throws Exception {

		if (v) {
			p1.append("\n===== Cluster =====\n");
			p2.append("\n===== Search Outlier ====\n");
		}
		resetOptions();

		this.count_computeOut = 0;
		this.count_underTrheshold = 0;
		this.count_out_threshold = 0;

		if(v)System.out.println("OPD Apriori");

		Instances data = new Instances(new BufferedReader(new FileReader(
				nomeFile)));

		this.clu = doCluster;
		
		// TODO

		this.nomeFCluster = data.relationName() + "_CJ";

//
//		this.nomeFCluster = cluster_file;

		// System.out.println("build...");
		this.build(data);

	}

	public OPD_Levels_Main(String nomeFile, String cluster_file, boolean b,
			int id_out, int levels2, int k2, double omega2, boolean tecnica2,
			double threshold2) throws Exception {
		// TODO Auto-generated constructor stub

		if (v) {
			p1.append("\n===== Cluster =====\n");
			p2.append("\n===== Search Outlier ====\n");
		}

		// resetOption
		tecnica = tecnica2;
		out = id_out;
		sigma = threshold2;
		levels = levels2;
		k = k2;
		omega = omega2;

		String tec = null;
		if (tecnica)
			tec = "omega";
		else
			tec = "topk";

		if(v)System.out.println("OPD Apriori --> " + tec);
		this.count_computeOut = 0;
		this.count_underTrheshold = 0;
		this.count_out_threshold = 0;

		Instances data = new Instances(new BufferedReader(new FileReader(
				nomeFile)));

		this.clu = b;
		this.nomeFCluster = cluster_file;

		if(v)System.out.println("build...");
		this.build(data);

	}

	@Override
	public void build(Instances data) throws Exception {

		data = new Instances(data);
		this.M = data.numAttributes();
		this.N = data.numInstances();

		if(v)System.out.println("\t\t N: " + N + " - M: " + M);

		this.cluster = new int[N][M];

		this.dataset = new double[N][M];

		for (int i = 0; i < N; i++) {

			Instance m = data.instance(i);
			double[] h = m.toDoubleArray();
			for (int j = 0; j < M; j++) {
				dataset[i][j] = h[j];
				// System.out.println(h[i]);
			}
		}

		this.attr_apriori = new boolean[M];
		this.a_new = new boolean[M];

		this.A = new BitSet(N);
		this.B = new BitSet(N);

		this.id = new int[N];
		// L'outlier far� sempre parte delle righe selezionate da una
		// spiegazione
		for (int i = 0; i < N; i++)
			id[i] = i;

		this.eid = new int[M];

		this.expl_vuota = new boolean[M];

		if (tecnica) {
			// omega
			this.result = new LinkedList<Result>();

		} else {
			// topk
			this.id_heap = new int[M];
			for (int i = 0; i < id_heap.length; i++) {
				id_heap[i] = -1;
			}
			topk = new MyHeap(k, MyHeap.MIN_HEAP, id_heap);
		}

		if (clu == true) {
			clusterDiscretize();
			if(v)System.out.println("===> FIRST PHASE ENDED <===");
			findProperty(out, sigma, levels, k);
		} else {
			leggiCluster(nomeFCluster);
			
			if(v)System.out.println("===> FIRST PHASE ENDED <===");
			findProperty(out, sigma, levels, k);
		}

	}

	public int getOut() {
		return this.out;
	}

	public double getOut_Threshold() {
		return this.omega;
	}

	public double getThreshold() {
		return this.sigma;
	}

	public int getLevels() {
		return this.levels;
	}

	public int getK() {
		return this.k;
	}

	public void setOut(int id) {
		this.out = id;
	}

	public void setOut_Threshold(double id) {
		this.omega = id;
	}

	public void setThreshold(double t) {
		this.sigma = t;
	}

	public void setLevels(int l) {
		this.levels = l;
	}

	public void setK(int k) {
		this.k = k;
	}

	public boolean getVerbose() {
		return this.v;
	}

	public boolean getDoCluster() {
		return this.clu;
	}

	public void setVerbose(boolean b) {
		this.v = b;
	}

	public boolean getTecnique() {
		return this.tecnica;
	}

	public void setTecnique(boolean t) {
		this.tecnica = t;
	}

	public void setDoCluster(boolean b) {
		this.clu = b;
	}

	// Passo 1
	private void clusterDiscretize() throws Exception {


		/*this.cluster = new int[N][M];

		long start, elapsed, time = 0;

		EM[] em = new EM[M];
		Remove filter = new Remove();

		for (int i = 0; i < M; i++) {
			em[i] = new EM();
			em[i].setNumClusters(-1);

			filter.setInputFormat(data);
			String range;
			if (i == 0)
				range = "2-last";
			else if (i == M - 2)
				range = "first-" + (M - 2) + ",last";
			else if (i == M - 1)
				range = "first-" + (M - 1);
			else if (i == 1)
				range = "first,3-last";
			else
				range = "first-" + i + "," + (i + 2) + "-last";

			String[] options = new String[2];
			options[0] = "-R";
			options[1] = range;

			filter.setOptions(options);
			if (v)
				p1.append("\nWorking on range: " + range + "... ");

			start = System.currentTimeMillis();
			Instances filtered = filter.useFilter(data, filter);
			em[i].buildClusterer(filtered);
			elapsed = System.currentTimeMillis() - start;
			time += elapsed;

			if (v)
				p1.append("done [" + (elapsed / 1000.0) + "secs, "
						+ em[i].numberOfClusters() + " intervals]");

			for (int j = 0; j < N; j++)
				cluster[j][i] = em[i].clusterInstance(filtered.instance(j));
		}

		PrintWriter p = new PrintWriter(data.relationName() + "_CJ" + ".txt");

		this.nomeFCluster = data.relationName() + "_CJ";
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++)
				p.print(cluster[i][j] + " ");
			p.println();
		}
		p.flush();
		p.close();

		p1.append("\n\nTime elapsed: " + (time / 1000.0) + " secs\n");
		this.time_p1 = (time / 1000.0);
		p1.append("\n===================================================\n");*/
		
		this.cluster = new int[N][M];

		double alpha = 0.1; //1e-4;

		long start, elapsed, time = 0;

		EMDiscretizer[] em = new EMDiscretizer[M];

		for (int i = 0; i < M; i++) {
			em[i] = new EMDiscretizer(i,alpha);

			//System.out.print("Working on attribute: " + i + " ...");

			if (v)
				p1.append("\nWorking on attribute: " + i + "... ");

			start = System.currentTimeMillis();
			long start1 = System.currentTimeMillis();
			em[i].buildClusterer(this.dataset);
			long elapsed2 = System.currentTimeMillis() - start1;
			elapsed = System.currentTimeMillis() - start;
			time += elapsed;

			if(v){
				/*System.out.println("done [" + (elapsed / 1000.0) + "secs (clustering " + (elapsed2 / 1000.0) + "secs), "
						+ em[i].numberOfClusters() + " intervals]");
				System.out.println(em[i]);*/
				p1.append("done [" + (elapsed / 1000.0) + "secs (clustering " +
(elapsed2 / 1000.0) + "secs), "
						+ em[i].numberOfClusters() + " intervals]");
			}

			for (int j = 0; j < N; j++)
				cluster[j][i] = em[i].clusterInstance(dataset[j][i]);
		}

		// System.out.println("Time elapsed: " + (time / 1000.0) + "secs");

		PrintWriter p = new PrintWriter(N+"_"+M+"_CJ" + ".txt");

		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++)
				p.print(cluster[i][j] + " ");
			p.println();
		}
		p.flush();
		p.close();

		p1.append("\n\nTime elapsed: " + (time / 1000.0) + " secs\n");
		this.time_p1 = (time / 1000.0);
		p1.append("\n===================================================\n");

	}

	// passo 2

	/**
	 * ok
	 * 
	 * @param id
	 * @param treshold
	 * @param livelli
	 * @param k
	 */
	public void findProperty(int out, double treshold, int levels, int k) {
		this.out_stampa = out;

		long start = System.currentTimeMillis();

		int id_out = out - 1;

		// Metto in prima posizione (indice 0) la riga del dataset e del cluster
		// relativa all id dell outlier
		double[] firstRow_temp = dataset[0];
		dataset[0] = dataset[id_out];
		dataset[id_out] = firstRow_temp;
		
		int[] firstRow_tempCluster = cluster[0];
		cluster[0] = cluster[id_out];
		cluster[id_out] = firstRow_tempCluster;

		// prima posizione: indice 0
		id_out = 0;
		this.out = id_out;

		double min_n = Math.ceil(N * treshold);

		if (tecnica == false)
			searchOutlier_TopK(id_out, min_n, levels);
		else
			searchOutlier_Omega(id_out, min_n, levels);

		long elapsed = System.currentTimeMillis() - start;
		this.time_p2 = (elapsed / 1000.0);
		if (v) {
			p2.append("\n\n\nTime elapsed: " + time_p2 + " secs\n");
			p2.append("==================================================");
		}

	}

	public void searchOutlier_TopK(int id_out, double min_n, int levels) {

		int level = 0;

		// L_0=vuoto

		Trie L_j_1 = new Trie(M);
		Trie L_j = new Trie(M), E_j;
		double out_value;

		for (int attr = 0; attr < M; attr++) {
			if (v)
				p2.append("\n\n\n\t Property: " + (attr + 1));

			L_j_1.reset();
			// spiegazione vuota
			L_j_1.insert2(expl_vuota);

			resetAttrApriori();
			// escludo la propriet�.. non potr� far parte delle spiegazioni!!!
			attr_apriori[attr] = false;

			// oulierness con spiegazione vuota
			select3(expl_vuota);
			if (s > min_n - 1) {

				out_value = computeOutlierness(id_out, attr, N);

				if (v) {
					p2.append("\nSearch with explanation: ");
					p2.append(stampaSpiegazione(expl_vuota));
					// p2.append("\n\t Property: " + (attr + 1));
					p2.append(".... OUT: " + Utility.arrotonda(out_value, 2));
				}

				update_topk(attr, expl_vuota, out_value, level);

				level = 1;
				while (level <= levels && L_j_1.size() != 0) {

					L_j_1.clearStack();
					E_j = generate(L_j_1, level);
					L_j = L_j.reset();

					boolean[] expl;

					while ((expl = E_j.get()) != null) {

						if (v) {
							p2.append("\nSearch with explanation: ");
							p2.append(stampaSpiegazione(expl));

						}

						select3(expl);
						if (s > min_n - 1) {
							out_value = computeOutlierness(id_out, attr, s);
							update_topk(attr, expl, out_value, level);
							//
							L_j.insert2(expl);

							if (v){
								p2.append(".... OUTLIERNESS: "
										+ Utility.arrotonda(out_value, 2));
							}

						} else {
							// soglia supportp
							this.count_underTrheshold++;

							if (v)
								p2.append(" ---> Under threshold!!!");

						}

					}// while

					L_j_1 = L_j;
					level++;
				}// level<levels

			} else {
				this.count_underTrheshold++;
				if (v) {
					p2.append(" ---> Under threshold!!!");
				}
			}
		}

	}// searchOutlier_TopK

	/**
	 * 
	 * @param attr
	 * @param explanation
	 * @param out
	 * @param l
	 */

	public void update_topk(int attr, boolean[] explanation, double out, int l) {

		topk.insertGeneric(out, attr, explanation, l);

	}

	public void searchOutlier_Omega(int id_out, double min_n, int levels) {

		int level = 0;
		// L_0=vuoto

		Trie L_j_1 = new Trie(M);
		Trie L_j = new Trie(M), E_j;
		double out_value;
		for (int attr = 0; attr < M; attr++) {
			p2.append("\n\n\t Property: " + (attr + 1));

			L_j_1.reset();

			L_j_1.insert2(expl_vuota);

			resetAttrApriori();
			attr_apriori[attr] = false;
			select3(expl_vuota);
			if (s > min_n - 1) {

				// oulierness con spiegazione vuota
				out_value = computeOutlierness(id_out, attr, N);
				if (v) {
					p2.append("\nSearch with explanation: ");
					p2.append(stampaSpiegazione(expl_vuota));
					// p2.append("\n\t Property: " + (attr + 1));
					p2.append(".... OUT: " + Utility.arrotonda(out_value, 2));
				}

				if (out_value >= omega) {

					update_result_Omega(attr, expl_vuota, out_value);
					this.count_out_threshold++;

					if (v)
						p2.append("\n\t\t Outlierness exceeds the threshold Omega:  "
								+ Utility.arrotonda(out_value, 2)
								+ " >= "
								+ omega);

				} else {
					level = 1;
					boolean relevant;
					while (level <= levels && L_j_1.size() != 0) {

						L_j_1.clearStack();
						E_j = generate(L_j_1, level);
						L_j = L_j.reset();

						boolean[] expl;
						while ((expl = E_j.get()) != null) {

							if (v) {
								p2.append("\nSearch with explanation: ");
								p2.append(stampaSpiegazione(expl));

							}

							relevant = select3(expl);
							if (relevant && s > min_n - 1) {
								out_value = computeOutlierness(id_out, attr, s);
								if (v)
									p2.append(".... OUT: "
											+ Utility.arrotonda(out_value, 2));

								if (out_value >= omega) {

									this.count_out_threshold++;
									update_result_Omega(attr, expl, out_value);
									// pongo attr_top[i]=false per ogni i di
									// expl ==1
									for (int i = 0; i < expl.length; i++)
										if (expl[i])
											attr_apriori[i] = false;

									if (v)
										p2.append("\n\t\t Upper outlierness Threshold:  "
												+ Utility.arrotonda(out_value,
														2) + " >= " + omega);

								} else {

									L_j.insert2(expl);
								}
							} else {
								// soglia supportp

								this.count_underTrheshold++;
								if (v) {
									if(relevant)
										p2.append("---> Under support threshold!!!");
									else
										p2.append("---> Irrelevant!!!");
								}
							}
						}// while
						L_j_1 = L_j;
						level++;
					}// level<levels
				}
			} else {
				this.count_underTrheshold++;
				if (v) {
					p2.append("--> Under threshold!!!");
				}
			}
		}
	}

	public void update_result_Omega(int attr, boolean[] explanation, double out2) {

		this.result.add(new Result(out2, attr, explanation));

	}

	/**
	 * mette a true tutti tutti i valori del vettore attr_apriori. tutti gli
	 * attributi in questo modo possono essere inseriti nelle spiegazioni.
	 */

	private void resetAttrApriori() {

		for (int i = 0; i < attr_apriori.length; i++) {
			attr_apriori[i] = true;
		}

	}

	public Trie generate(Trie L_j, int level) {

		// anew= nuovi attributi validi nella spiegazione
		for (int i = 0; i < a_new.length; i++) {
			a_new[i] = false;
		}

		Trie res = new Trie(M);

		if (level == 1) {
			// L_j=spiegazione vuota
			boolean[] e1;

			for (int i = 0; i < attr_apriori.length; i++) {
				if (attr_apriori[i] == true) {
					e1 = new boolean[M];
					e1[i] = true;
					select3(e1);
					if (s > this.sigma) {

						res.insert2(e1);

						a_new[i] = true;
					}
				}

			}

		} else {

			boolean[] C;

			while ((C = L_j.get()) != null) {

				int indice = find(C, true);

				boolean[] C_new;
				for (int i = indice + 1; i < attr_apriori.length; i++) {
					if (attr_apriori[i] == true) {
						// nuovo candidato = C={c1,c2,..} + i

						C_new = new boolean[C.length];
						if (esistonoSottoInsiemi(C, i, L_j)) {
							for (int j = 0; j < C_new.length; j++) {
								C_new[j] = C[j];
								if (C[j]) {
									a_new[i] = true;
								}
							}
							C_new[i] = true;
							a_new[i] = true;
							res.insert2(C_new);
						}// esistono sottoinsiemi

					}
				}
			}

		}

		for (int i = 0; i < attr_apriori.length; i++) {
			attr_apriori[i] = a_new[i];
		}

		return res;
	}// generate

	private boolean esistonoSottoInsiemi(boolean[] c, int p, Trie L_j) {

		int count = 0;
		int count_verificati = 0;

		for (int j = 0; j < c.length; j++) {
			if (c[j]) {
				count++;
				c[j] = false;
				c[p] = true;

				if (L_j.contains(c)) {
					count_verificati++;
				}

				c[j] = true;
				c[p] = false;

			}
		}
		return count == count_verificati;
	}

	private boolean select3(boolean[] e) {
		s = 1;
		id[0] = 0;
		int last = -1;
		for(int i=0; i<e.length; i++)
			if(e[i])
				last = i;
		boolean relevant = false;
		for(int i=1; i<N; i++){
				boolean ok = true;
				for (int a = 0; a < e.length && ok; a++){
						if(e[a] && cluster[0][a] != cluster[i][a]){
							ok = false;
							if(a==last)
								relevant = true;
						}
							
				}
				if(ok){
					id[s] = i;
					s++;
				}
		}
		return relevant;
/***************** TODO: CHECK *****************************/
/*
		int e_size = 0;

		// eid=attributi della spiegazione
		for (int i = 0; i < e.length; i++)
			if (e[i]) {
				eid[e_size] = i;
				e_size++;
			}

		
		if (e_size == 0) {
			s = N;
			return true;
		}

		s = 1;

		int r, c = eid[e_size - 1];

		int temp;

		boolean h = true;
		int s_old = 1;
		if(e_size==1){
			s_old = N;
		}

		for (int i = 1; i < N; i++) {
			r = id[i];
			h = true;

			if (e_size > 2) {

				for (int j = 0; j < e_size-1; j++) {
					if (cluster[r][eid[j]] != cluster[0][eid[j]]) {
						// end = true;
						h = false;
						break;
					}
				}
				if(h)
					s_old++;

				if (h && cluster[r][eid[e_size-1]] == cluster[0][eid[e_size-1]]) {
					temp = id[s];
					id[s] = id[i];
					id[i] = temp;
					s++;
				}

			} else {

				// e_size==2 or e_size==1
				if (e_size > 1
						&& cluster[r][eid[e_size - 2]] != cluster[0][eid[e_size - 2]]) {
					h = false;

				} else if (h && cluster[r][c] == cluster[0][c]) {
					// System.out.println("size: " + (r + 1) + "- ");
					temp = id[s];
					id[s] = id[i];
					id[i] = temp;
					s++;
				}
			}
		}// for

		return (s<s_old);*/

	}// select

	/**
	 * 
	 * @param id_out
	 * @param matrice_creata
	 * @param attr
	 * @return
	 */
	public double computeOutlierness(int id_out, int attr, int s) {

		this.count_computeOut++;
		double out_result = 0;

		double[] d = new double[s];
		for (int riga = 0; riga < s; riga++) {
			d[riga] = dataset[id[riga]][attr];

		}

		if (Utility.standardDeviation2(d) == 0) {
			return out_result = 0;
		}

		double[] f = estimatePDF(d);// , m);

		double[] G = Utility.cumulata(s);

		PairSort p = Utility.sort__2(f);

		int[] index = p.getIndex();

		int sid = -1;
		for (int i = 0; i < index.length; i++) {
			if (index[i] == id_out)
				sid = i;

		}

		if (sid == s - 1) {
			return out_result = 0;
		}

		out_result = compute_value_out(sid, s, G, p.getEl());

		return out_result;

	}

	/**
	 * ok
	 * 
	 * @param data
	 * @return
	 */

	public double[] estimatePDF(double[] data) {// , Matrix m_data) {

		// long start = System.currentTimeMillis();
		int n = data.length;
		double h = 1.06 * Utility.standardDeviation2(data)
				* Math.pow(n, -(double) 1 / 5);

		double[] weight = new double[n];
		for (int i = 0; i < weight.length; i++) {
			weight[i] = 1;

		}

		double[] f = computePDF(data, weight, h);

		double geo_mean = Utility.mediaGeometrica(f);

		// weight=sqrt(fmean./f);
		// weight[i]=fmean/f[i]

		// weight = update_weight(geo_mean, f, weight)
		for (int i = 0; i < weight.length; i++) {
			weight[i] = Math.sqrt((double) geo_mean / f[i]);
		}

		// long end = System.currentTimeMillis() - start;
		// System.out.println("estimate PDF -->" + (end / 1000.0));

		return f;
	}

	public double[] computePDF(double[] data, double[] weight, double h) {

		// long start = System.currentTimeMillis();

		int n = data.length;
		// System.out.println("\n--------------> N " + n);

		double[] weight_op = new double[weight.length];
		for (int i = 0; i < weight.length; i++) {
			weight_op[i] = weight[i] * (double) h / 2;
		}

		PairSort lower = Utility.sort__2(Utility.minus(data, weight_op));
		PairSort upper = Utility.sort__2(Utility.plus(data, weight_op));

		int[] lw = lower.getIndex();
		int[] up = upper.getIndex();

		double[] f = new double[n];
		double sum = 0;

		int l_i, u_i;

		for (int i = 0; i < n; i++) {

			A.reset();
			B.reset();

			l_i = Utility.ricerca2(data[i], lower.getEl(), false);
			u_i = Utility.ricerca2(data[i], upper.getEl(), true);

			for (int j = 0; j <= l_i; j++) {
				A.set(lw[j]);
			}

			for (int j = u_i; j < n; j++) {
				B.set(up[j]);
			}

			A.intersect(B);

			sum = 0;

			for (int j = 0; j < N; j++) {
				if (A.get(j)) {
					sum += (double) 1 / weight[j];
				}
			}

			f[i] = (double) sum / (n * h);

		}

		// long end1 = System.currentTimeMillis() - start1;
		// System.out.println("\nfor  -->" + (end1 / 1000.0));

		// long end = System.currentTimeMillis() - start;
		// System.out.println("Compute PDF  -->" + (end / 1000.0));
		return f;
	}

	/**
	 * ok
	 * 
	 * @param sid
	 * @param n
	 * @param g
	 * @param el
	 * @return
	 */

	public double compute_value_out(int sid, int n, double[] g, double[] el) {

		// out=sum(diff(fs(sid:n)).*(2-G(sid+1:n)-G(sid:n-1))/2);

		double[] fs = Utility.subArrayD2(el, sid, n - 1);

		double[] g1 = Utility.subArrayD2(g, sid + 1, n - 1);

		double[] g2 = Utility.subArrayD2(g, sid, n - 2);

		double[] diff = Utility.diff(fs);

		double out_value = 0;
		for (int i = 0; i < diff.length; i++) {
			out_value += diff[i] * ((2 - g1[i] - g2[i]) / 2);
		}

		out_value = (1 - Math.exp(-out_value)) / (1 + Math.exp(-out_value));
		// return Utility.arrotonda(out_value,6);
		return out_value;

	}

	/**
	 * Trova in explanation l'ultimo indice di uno (ossia di true) se esiste
	 * 
	 * @param explanation
	 * @param number
	 * @return
	 */
	private int find(boolean[] explanation, boolean number) {
		int index = -1;
		for (int i = 0; i < explanation.length; i++) {
			if (explanation[i] == number)
				index = i;
		}
		return index;
	}

	// passo 2

	public String toString() {
		// return stampaMatrice(cluster, "Matrice Cluster") + " \n \n "
		// + stampaDataset(dataset, "Dataset") + "\n \n "
		// + printMatrix(this.result, "Matrice Risultato: ");

		if (error)
			return error_s.toString();
		else {
			String s1 = p1.toString();
			String s2 = p2.toString();
			String result;
			if (tecnica)
				result = printResult_Omega();
			else
				result = printResult_TopK();
			String res = s1 + "\n " + s2 + " \n\n === Result === \n" + result;

			return res;
		}

	}

	public String printResult_Omega() {
		StringBuilder sb = new StringBuilder();
		sb.append("ALGORITHM: Apriori - Out Threshold (omega)\n");

		sb.append("DATASET:\n");
		sb.append("\t Instances: " + N + "\n");
		sb.append("\t Attributes: " + M + "\n");

		sb.append("\nPARAMETERS: \n");
		sb.append("\t Id_out: " + (this.out_stampa) + "\n");
		sb.append("\t Threshold: " + this.sigma + "\n");
		sb.append("\t Levels: " + this.levels + "\n");
		sb.append("\t Out_thres: " + this.omega + "\n");

		sb.append("\nTIMES:\n");
		sb.append("\t Time part 1: " + this.time_p1);
		sb.append("\n\t Time part 2: " + this.time_p2);
		sb.append("\n\t Total Time: " + (this.time_p2 + this.time_p1));

		sb.append("\nCOUNT:\n");
		sb.append(" # Compute Outlierness: " + this.count_computeOut + "\n");
		sb.append(" # Under threshold dataset: " + this.count_underTrheshold
				+ "\n");
		sb.append(" # Upper outlierness threshold:  "
				+ this.count_out_threshold + "\n");

		sb.append("\n\nRESULT: \n");

		Iterator<Result> rr = result.iterator();

		while (rr.hasNext()) {
			// System.out.println(rr[i]);
			Result r = rr.next();
			sb.append("\tValue: " + Utility.arrotonda(r.getOut(), 4));
			sb.append("\t Property: " + Integer.toString((r.getAttr() + 1)));
			sb.append("\t Explanation: ");
			sb.append("{ ");
			for (int j = 0; j < r.getExpl().length; j++) {
				if (r.getExpl()[j]) {
					sb.append("[" + (j + 1) + "");
					sb.append(" @"
							+ find_intervallo_spiegazione(out, r.getAttr())
							+ "] ");

				}

			}
			sb.append("}");
			sb.append("\n");
		}

		sb.append("\n\n");

		return sb.toString();
	}

	public String printResult_TopK() {
		StringBuilder sb = new StringBuilder();
		sb.append("ALGORITHM: Apriori- TopK\n");
		sb.append("DATASET:\n");
		sb.append("\t Instances: " + N + "\n");
		sb.append("\t Attributes: " + M + "\n");

		sb.append("\nPARAMETERS: \n");
		sb.append("\t Id_out: " + (this.out_stampa) + "\n");
		sb.append("\t Threshold: " + this.sigma + "\n");
		sb.append("\t Levels: " + this.levels + "\n");
		sb.append("\t K: " + this.k + "\n");
		sb.append("\t Out_threshold: " + this.omega + "\n");

		sb.append("\nTIMES:\n");
		sb.append("\t Time part 1: " + this.time_p1);
		sb.append("\n\t Time part 2: " + this.time_p2);
		sb.append("\n\t Total Time: " + (this.time_p2 + this.time_p1));

		sb.append("\nCOUNT:\n");
		sb.append(" # Compute Outlierness: " + this.count_computeOut + "\n");
		sb.append(" # Under threshold: " + this.count_underTrheshold + "\n");

		sb.append("\n\nRESULT: \n");

		Result[] rr = topk.getOrderedArray();

		for (int i = 0; i < rr.length; i++) {

			Result r = rr[i];
			sb.append("\tValue: " + Utility.arrotonda(r.getOut(), 4));
			sb.append("\t Property: " + Integer.toString((r.getAttr() + 1)));
			sb.append("\t Explanation: ");
			sb.append("{ ");
			for (int j = 0; j < r.getExpl().length; j++) {
				if (r.getExpl()[j]) {
					sb.append("[" + (j + 1) + "");
					sb.append(" @"
							+ find_intervallo_spiegazione(out, j)
							+ "] ");

				}

			}
			sb.append("}");
			sb.append("\n");
		}

		sb.append("\n\n");

		return sb.toString();

	}

	/**
	 * PANNELLO PARAMETR. SEZIONE ABOUT.. NN CI SONO CAPABILITIES!!!
	 */

	public Pair find_intervallo_spiegazione(int id_out, int prop) {
		int clu = this.cluster[id_out][prop];
		double[] v = new double[N];
		int count = 0;
		for (int i = 0; i < N; i++) {
			if (this.cluster[i][prop] == clu) {
				v[count] = dataset[i][prop];
				count++;
			}
		}
		double min = v[0], max = v[0];
		for (int i = 1; i < count; i++) {
			if (v[i] < min)
				min = v[i];
			if (v[i] > max)
				max = v[i];
		}

		return new Pair(min, max);
	}

	public String stampaSpiegazione(boolean[] e) {
		StringBuilder sb = new StringBuilder();

		sb.append("{ ");
		for (int i = 0; i < e.length; i++) {
			if (e[i])
				sb.append((i + 1) + " ");
		}
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Returns a string describing this clusterer
	 * 
	 * @return a description of the evaluator suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	public String globalInfo() {
		return "OPD - Outlying Property Detector.\n\n";
		// + "EM assigns a probability distribution to each instance which "
		// +
		// "indicates the probability of it belonging to each of the clusters. "
		// +
		// "EM can decide how many clusters to create by cross validation, or you "
		// + "may specify apriori how many clusters to generate.\n\n"
		// +
		// "The cross validation performed to determine the number of clusters "
		// + "is done in the following steps:\n"
		// + "1. the number of clusters is set to 1\n"
		// + "2. the training set is split randomly into 10 folds.\n"
		// +
		// "3. EM is performed 10 times using the 10 folds the usual CV way.\n"
		// + "4. the loglikelihood is averaged over all 10 results.\n"
		// +
		// "5. if loglikelihood has increased the number of clusters is increased "
		// + "by 1 and the program continues at step 2. \n\n"
		// + "The number of folds is fixed to 10, as long as the number of "
		// +
		// "instances in the training set is not smaller 10. If this is the case "
		// + "the number of folds is set equal to the number of instances.";
	}

	/**********************************************************************
	 * OptionHandler Interface
	 ********************************************************************** 
	 */

	/**
	 * List Option: id_out, threshold, levels, k
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Enumeration listOptions() {
		// TODO Auto-generated method stub

		// Option(String description, String name, int numArguments, String
		// synopsis)

		Vector result = new Vector();

		result.addElement(new Option("\tverbose", "V", 0, "-V"));
		result.addElement(new Option("\tflag", "F", 0, "-F"));

		result.addElement(new Option("\tOut", "O", 1, "-O <num>"));
		result.addElement(new Option("\t Threshold", "T", 1, "-T <num>"));

		result.addElement(new Option("\tLevels", "L", 1, "-L <num>"));

		result.addElement(new Option("\tK", "K", 1, "-K <num>"));

		// verbose

		return result.elements();

	}

	@Override
	public void setOptions(String[] options) throws Exception {
		resetOptions();

		this.setVerbose(Utils.getFlag("V", options));
		this.setDoCluster(Utils.getFlag("F", options));

		/**
		 * Parametri: o,threshold,levels,k
		 */
		String optionString = Utils.getOption("O", options);
		if (optionString.length() > 0) {
			this.setOut(Integer.parseInt(optionString));
		}

		optionString = Utils.getOption("T", options);
		if (optionString.length() > 0) {
			this.setThreshold(Double.parseDouble(optionString));
		}

		optionString = Utils.getOption("L", options);
		if (optionString.length() > 0) {
			this.setLevels(Integer.parseInt(optionString));
		}

		optionString = Utils.getOption("K", options);
		if (optionString.length() > 0) {
			this.setK(Integer.parseInt(optionString));
		}

	}

	@SuppressWarnings({ "rawtypes", "unused", "unchecked" })
	@Override
	public String[] getOptions() {
		// TODO Auto-generated method stub

		Vector result;
		String[] options;

		result = new Vector();

		result.add("-O");
		result.add("" + out);
		result.add("-T");
		result.add("" + sigma);
		result.add("-L");
		result.add("" + levels);
		result.add("-K");
		result.add("" + k);
		if (v)
			result.add("-V");

		return (String[]) result.toArray(new String[result.size()]);

	}

	@Override
	public Capabilities getCapabilities() {
		return null;
	}

	public void leggiCluster(String nome) throws Exception {
		
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(nome));
			if(this.v)System.out.println("FILE LETTO!");
			String text;

			int i = 0, j;

			StringTokenizer st;

			while ((text = br.readLine()) != null) {

				st = new StringTokenizer(text);
				j = 0;
				while (st.hasMoreElements()) {

					this.cluster[i][j] = Integer.parseInt((String) st.nextElement());

					j++;

				}

				i++;
				// buffer.append(text + "\n");
			}
			br.close();
		} catch (FileNotFoundException e) {
			System.out.println(nome+"notFound");
			System.exit(1);
			clusterDiscretize();
		}


	}

	protected void resetOptions() {
		
		levels = 7;
		k = 1;
		v = false;
		clu = false;
		//false = legge da file

		this.tecnica = false;
		// false= topk

		
		out = 223;
		
		sigma = 0.2;
		this.omega = 0.1;
		
	}

	public static void main(String[] args) throws Exception {
		
		String nome = "cloud_weka.arff"; //MAGRTNSCI10014_data-intermittency.arff";
		OPD_Levels_Main op = new OPD_Levels_Main(nome, false);
		System.out.println(op.toString());
		
		/*String dsfilename = args[0];
		String clustfilename = args[1];
		int level = Integer.valueOf(args[2]);
		int out =  Integer.valueOf(args[3]);
		double sigma = Double.valueOf(args[4]);*/
		//nomeFile, cluster_file, clu, id_out, levels, k, omega, tecnica, sigma
		//OPD_Levels_Main op1 = new OPD_Levels_Main(dsfilename, clustfilename, false,
				//out, level, 1, 0.1, false, sigma);
		//System.out.println(op1.toString());
	}

}
