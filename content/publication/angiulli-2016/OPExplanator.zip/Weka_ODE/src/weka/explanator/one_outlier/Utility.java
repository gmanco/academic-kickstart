package weka.explanator.one_outlier;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

/**
 * Classe contenente metodi di utilit� per calcolare l'outlierness.
 * 
 * 
 */
public class Utility {

	static int arr = 6;

	public static double standardDeviation2(double[] v) {
		double dev = 0.0;
		int n = v.length - 1;
		double m_artitmetica = mediaAritmetica(v);
		double sum = 0;
		for (int i = 0; i < v.length; i++) {
			sum += Math.pow((v[i] - m_artitmetica), 2);
		}
		double sottoradice = sum / n;
		dev = Math.sqrt(sottoradice);
		return dev;
	}

	public static double mediaAritmetica(double[] v) {
		double sum = 0;
		int n = v.length;
		for (int i = 0; i < v.length; i++) {
			sum += v[i];

		}
		return sum / n;
	}

	public static double mediaGeometrica(double[] v) {
		double prod = 1;
		int n = v.length;
		for (int i = 0; i < v.length; i++) {
			prod *= v[i];

		}
		return Math.pow(prod, (double) 1 / n);
	}

	/**
	 * 
	 * @param key
	 * @param is
	 * @param bool
	 * @return
	 */

	public static int ricerca2(double key, double[] data, boolean bool) {
		int n = data.length;
		int a = 0;
		int b = n - 1;
		int c;
		while (a <= b) {
			c = (int) Math.floor((a + b) / 2);
			if (key < data[c] || (key == data[c] && bool))
				b = c - 1;
			else
				a = c + 1;
		}
		if (bool)
			c = a;
		else
			c = b;
		return c;
	}

	/**
	 * 
	 * @param data2
	 * @param weight
	 * @return
	 */

	public static double[] minus(double[] data2, double[] weight) {
		// TODO Auto-generated method stub
		double[] minus = new double[data2.length];
		for (int i = 0; i < minus.length; i++) {
			// minus[i] = arrotonda(data2[i] - weight[i],arr);
			minus[i] = data2[i] - weight[i];
		}
		return minus;
	}

	/**
	 * 
	 * @param data2
	 * @param weight
	 * @return
	 */
	public static double[] plus(double[] data2, double[] weight) {
		// TODO Auto-generated method stub
		double[] add = new double[data2.length];
		for (int i = 0; i < add.length; i++) {
			// add[i] = arrotonda(data2[i] + weight[i],arr);
			add[i] = data2[i] + weight[i];
		}
		return add;
	}

	/**
	 * 
	 * @param n
	 * @return
	 */
	public static double[] cumulata(int n) {
		// TODO Auto-generated method stub
		double[] G = new double[n];
		for (int i = 0; i < G.length; i++) {
			// G[i] = arrotonda((double) (i + 1) / n,6);
			G[i] = (double) (i + 1) / n;
		}

		return G;
	}

	public static PairSort sort__2(double[] f) {

		List<Pair> l = new LinkedList<Pair>();
		for (int i = 0; i < f.length; i++) {
			l.add(new Pair(f[i], i));
		}

		Collections.sort(l, new Comparator<Pair>() {
			@Override
			public int compare(Pair o1, Pair o2) {
				// TODO Auto-generated method stub
				if (o1.getValue() < o2.getValue())
					return -1;
				if (o1.getValue() > o2.getValue())
					return 1;
				return 0;
			}
		});

		double[] values = new double[f.length];
		int[] index = new int[f.length];

		ListIterator<Pair> lit = (ListIterator<Pair>) l.iterator();
		int k = 0;
		while (lit.hasNext()) {
			Pair p = lit.next();

			values[k] = p.getValue();
			index[k] = p.getIndex();
			k++;
		}

		PairSort p = new PairSort(values, index);

		return p;

	}

	public static double[] subArrayD2(double[] l, int start, int end) {
		// TODO Auto-generated method stub

		int dim = end - start + 1;
		double[] result = new double[dim];
		// List<Double> res = new LinkedList<Double>();
		int j = start;
		for (int i = 0; i < result.length; i++) {
			result[i] = l[j];
			j++;
		}

		return result;
	}

	public static double[] diff(double[] l) {
		double[] res = new double[l.length - 1];

		for (int i = 0; i < res.length; i++) {
			res[i] = l[i + 1] - l[i];

		}
		return res;
	}

	/**
	 * Conta in J le occorrenze di num
	 * 
	 * @param J
	 * @param num
	 * @return
	 */
	public static int count_el(int[] J, int num) {
		// TODO Auto-generated method stub
		int count = 0;
		for (int i = 0; i < J.length; i++) {
			if (J[i] == num)
				count++;
		}
		return count;
	}

	public static double arrotonda(double numero, int nCifreDecimali) {
		return Math.round(numero * Math.pow(10, nCifreDecimali))
				/ Math.pow(10, nCifreDecimali);
	}

	/*
	 * Non usati nel progetto
	 */
	public static void quickSort2(int[] a, int i, int f) {
		if (i >= f)
			return;
		int m = partiziona(a, i, f);
		quickSort2(a, i, m - 1);
		quickSort2(a, m + 1, f);

	}

	private static int partiziona(int[] a, int i, int f) {
		// TODO Auto-generated method stub
		int inf = i;
		int sup = f + 1;
		int perno = i + (int) Math.floor((f - i + 1) * Math.random());

		int temp, x = a[perno];

		a[perno] = a[i];
		a[i] = x;
		while (true) {
			do {
				inf++;
			} while (inf <= f && a[inf] <= x);
			do {
				sup--;
			} while (a[sup] > x);

			if (inf < sup) {
				temp = a[inf];
				a[inf] = a[sup];
				a[sup] = temp;
			} else
				break;

		}
		temp = a[i];
		a[i] = a[sup];
		a[sup] = temp;
		return sup;
	}

	public static int ricercaBinaria(int[] data, int key) {
		int n = data.length;
		int a = 0;
		int b = n - 1;

		int c;

		while (a <= b) {
			c = (int) Math.floor((a + b) / 2);
			if (data[c] == key)
				return c;

			if (data[c] < key)
				a = c + 1;
			else
				b = c - 1;

		}
		// key non c'�
		return -1;
	}

	public static void intersezione(int[] a, int b[]) {
		List<Integer> l = new LinkedList<Integer>();
		boolean trovato;
		for (int i = 0; i < a.length; i++) {
			trovato = false;
			for (int jj = 0; jj < b.length && !trovato; jj++)
				if (a[i] == b[jj]) {
					l.add(a[i]);
					trovato = true;

				}
		}

	}

	public static String stampaArray(int[] explanation) {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder();

		sb.append("[ ");
		for (int i = 0; i < explanation.length; i++) {
			sb.append(explanation[i] + " ");
		}
		sb.append("]");
		return sb.toString();
	}

}
