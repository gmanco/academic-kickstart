package weka.explanator.multiple_outliers;

import weka.core.Capabilities;
import weka.core.Instances;
import weka.explanator.Explanator;

public class EO implements Explanator{

	@Override
	public void build(Instances data) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Capabilities getCapabilities() {
		// TODO Auto-generated method stub
		return null;
	}

}
