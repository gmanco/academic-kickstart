package weka.explanator.one_outlier;
public class BitSet {
	int v[];

	BitSet(int dssize) {
		int n = ((int) Math.ceil(dssize / 32)) + 1;
		v = new int[n];
//		System.out.println("Dimensione v: " + n);
	}

	public void reset() {
		for (int i = 0; i < v.length; i++)
			v[i] = 0;
	}

	public void set(int i) {
		int base = i / 32;		
		int offset = i % 32;
//		System.out.println("i: "+i+" -> " + (1 << offset));
		v[base] = (v[base] | (1 << offset));
		
	}

	public void intersect(BitSet p) {
		for (int i = 0; i < v.length; i++)
			v[i] = (v[i] & p.v[i]);
	}

	public boolean get(int i) {
		int base = i / 32;
		int offset = i % 32;
		return ((v[base] & (1 << offset)) != 0);
	}

	public static void main(String args[]) {
	
		BitSet p = new BitSet(100);
		p.set(8);
		p.set(31);
		p.set(99);

		BitSet q = new BitSet(100);
		q.set(64);
		q.set(8);
		q.set(91);
		q.set(31);

		p.intersect(q);

		System.out.print("[ ");
		for (int i = 0; i < 100; i++) {
			if (p.get(i))
				System.out.print(i + " ");
		}
		System.out.println("]");
	}

}
