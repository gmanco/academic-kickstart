package weka.explanator.one_outlier;



public class MyHeap {
	static final int MIN_HEAP = 1;
	// Si tiene i valori più grandi e in testa mette il più piccolo
	static final int MAX_HEAP = -1;
	
	static final double eps = 0; //.0000001;

	// Si tiene i valori più piccoli e in testa mette il più grande

	class HeapNode {
		double key;
		Result element;
	}

	private int size; // Heap dimension
	private int count; // Current heap size
	private int mm;
	
	
	private int[] idx;

	public MyHeap(int size, int MAX_or_MIN, int[] idx) {
		this.size = size;
		count = 0;
		heap = new HeapNode[size];
		for(int i=0; i<size; i++){
			heap[i] = new HeapNode();
			heap[i].element = new Result(idx.length);
		}
		this.mm = MAX_or_MIN;
		this.idx = idx;
	}


	HeapNode[] heap;

	boolean heapifyUp(int i) {
		if (i == 0)
			return false;
		int parent = (int) Math.floor((i - 1) / 2);

		if (heap[i].key < heap[parent].key) {
			
			//SCAMBIA ID
			idx[heap[i].element.getAttr()] = parent;
			idx[heap[parent].element.getAttr()] = i;
			
			//SCAMBIA ELEMENTI
			HeapNode h = heap[i];
			heap[i] = heap[parent];
			heap[parent] = h;
			
			heapifyUp(parent);
			
			return true;
		}
		
		return false;
	}

	boolean heapifyDown(int i) {
		int smaller_child = 2 * i + 1;
		int larger_child = 2 * i + 2;
		if (smaller_child >= count) // Node i has not children
			return false;
		if (larger_child < count) { // Node i has a right child
			if (heap[smaller_child].key > heap[larger_child].key) {
				smaller_child = larger_child;
			}
		}
		
		if (heap[i].key > heap[smaller_child].key) {
			
			//SCAMBIA ID
			idx[heap[i].element.getAttr()] = smaller_child;
			idx[heap[smaller_child].element.getAttr()] = i;
			
			
//			System.out.print("[");
//			for (int j = 0; j < idx.length; j++) {
//				System.out.print(idx[j] + " ");
//			}
//			System.out.println("]\n");
			
			//SCAMBIA ELEMENTI
			HeapNode h = heap[i];
			heap[i] = heap[smaller_child];
			heap[smaller_child] = h;
			
			heapifyDown(smaller_child);
			return true;
		}
		return false;
	}

	void reset() {
		count = 0;
	}

	void remove(int i) {
		if (!(i < count))
			return;
		if (i == count - 1) {
			count--;
			return;
		}
		count--;
		if (count == 0)
			return;
		heap[i] = heap[count];
		int parent = (int) Math.floor((i - 1) / 2);
		if (i == 0 || heap[i].key > heap[parent].key)
			heapifyDown(i);
		else
			heapifyUp(i);
	}

	double popKey() {
		// print();
		if (count == 0) {
			return -1 * mm * Double.MAX_VALUE;
		}
		double key = mm * heap[0].key;
		count--;
		if (count > 0) {
			heap[0] = heap[count];
			heapifyDown(0);
		}
		// print();
		return key;
	}

	Result popValue() {
		if (count == 0) {
			return null;
		}
		Result e = heap[0].element;
		count--;
		if (count > 0) {
			heap[0] = heap[count];
			heapifyDown(0);
		}
		return e;
	}

	HeapNode popNode() {
		HeapNode node;
		if (count == 0) {
			node = new HeapNode();
			node.key = -1 * mm * Double.MAX_VALUE;
			node.element = null;
			return node;
		}
		node = heap[0];
		node.key = mm * node.key;
		count--;
		if (count > 0) {
			heap[0] = heap[count];
			heapifyDown(0);
		}
		return node;
	}
	
	void insertGeneric(double key, int p, boolean[] e, int l){
		
		int i=idx[p];
		
		if(i==-1){
			insert(key, p, e,l);
			return;
		}
		
		
		key = mm * key;
		
		if( key < heap[i].key ){
			return;
		}
		
		int li = heap[i].element.getLevel();
		
		if((key-heap[i].key) <= eps && l>=li){
			return;
		}
		
		heap[i].element.setExpl(e,l);
		heap[i].key = key;
		
		if(!heapifyUp(i))
			heapifyDown(i);
		
	}

	void insert(double key, int p, boolean[] e, int l) {
		
		key = mm * key;
		if (count < size) {
			
			idx[p] = count;
			
			heap[count].element.setAttr(p);
			heap[count].key = key;
			heap[count].element.setExpl(e,l);
			heapifyUp(count);
			count++;
		} else {
			if (key > heap[0].key) {

				//System.out.println(key + " > " +heap[0].key );
				
				idx[heap[0].element.getAttr()] = -1;
				idx[p] = 0;
				
//				System.out.print("[");
//				for (int i = 0; i < idx.length; i++) {
//					System.out.print(idx[i] + " ");
//				}
//				System.out.println("]");
				
				heap[0].element.setAttr(p);
				heap[0].key = key;
				heap[0].element.setExpl(e,l);
				heapifyDown(0);
				
				
			}
		}

	}

	int getSize() {
		return count;
	}

	Result[] getOrderedArray() {
		HeapNode[] heap_original = new HeapNode[size];
		int count_original = count;
		Result[] array = new Result[count];
		for (int i = 0; i < count; i++) {
			heap_original[i] = heap[i];
		}
		for (int i = 0; i < count_original; i++) {
			array[i] = heap[0].element;
			array[i].setOut(heap[0].key);
			heap[0] = heap[count_original - i - 1];
			count--;
			heapifyDown(0);
		}
		heap = heap_original;
		count = count_original;
		return array;
	}

	double getKey(int i) {
		return mm * heap[i].key;
	}

	double getTop() {
		if (count < size) {
			return -1 * mm * Double.MAX_VALUE;
		}
		return mm * heap[0].key;
	}

	HeapNode getNode(int i) {
		return heap[i];
	}

	Result getElement(int i) {
		return heap[i].element;
	}

	void print() {
		if (count == 0)
			return;
		System.out.print(mm * heap[0].key);
		for (int i = 1; i < count; i++)
			System.out.print(", " + mm * heap[i].key);
		System.out.println("\n");
	}

	
	public static void main(String args[]){
		int[] ids={-1,-1,-1,-1,-1,-1};
		boolean[] id=null;
		MyHeap heap = new MyHeap(5, MyHeap.MIN_HEAP,ids);
		heap.insertGeneric(3.9, 0, id, 1);
		heap.insertGeneric(  5, 1, id, 1);
		heap.insertGeneric(6.9, 2, id, 1);
		heap.insertGeneric(7.9, 3, id, 1);
		heap.insertGeneric(  3, 4, id, 1);
		heap.insertGeneric(7.1, 5, id, 1);
		heap.insertGeneric(7.5, 1, id, 1);
		
		System.out.print("[ ");
		for(int i:ids)
			System.out.print(i + " ");
		System.out.println("]");
		
		heap.print();
	
	}
}