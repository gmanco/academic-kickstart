package weka.explanator.one_outlier;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class ListConcatenata implements Iterable<Boolean> {

	class Node {
		boolean info; // true o false
		Node next;

		@Override
		public String toString() {
			return info + " - " + next.toString();
		}
	}

	private int length;

	Node testa;
	Node coda;

	public ListConcatenata() {
		testa = null;
		coda = null;
		length = 0;
	}

	public ListConcatenata(Node curr, Node coda, int length) {
		testa = curr;
		this.coda = coda;
		this.length = length;
	}

	public int size() {
		return length;
	}// cardinalita

	public ListConcatenata addExpl(boolean[] expl) {

		for (int i = 0; i < expl.length; i++) {
			this.add(expl[i]);

		}

		return this;
	}

	public void add(boolean b) {

		Node nuovo = new Node();
		nuovo.info = b;
		nuovo.next = null;

		if (testa == null) {
			// la lista � vuota
			testa = nuovo;
			coda = nuovo;
		} else {
			// inserimento in coda
			coda.next = nuovo;
			coda = nuovo;

		}

		length++;
	}

	public boolean getTesta() {
		return testa.info;
	}

	public boolean equals(Object o) {
		if (o == null || !(o instanceof ListConcatenata))
			return false;
		if (o == this)
			return true;
		ListConcatenata l = (ListConcatenata) o;

		Node cor1 = testa, cor2 = l.testa;
		while (cor1 != null) {// e' ridondante aggiungere: && cor2!=null
			if (cor1.info != cor2.info)
				return false;
			cor1 = cor1.next;
			cor2 = cor2.next;
		}
		return true;
	}// equals

	public Iterator<Boolean> iterator() {
		return new Iteratore();
	}// iterator

	private class Iteratore implements Iterator<Boolean> {
		private Node pre = null, cor = null;

		public boolean hasNext() {
			if (cor == null)
				return testa != null;
			return cor.next != null;
		}// hasNext

		public Boolean next() {
			if (!hasNext())
				throw new NoSuchElementException();
			if (cor == null)
				cor = testa;
			else {
				pre = cor;
				cor = cor.next;
			}
			return cor.info;
		}// next

		public void remove() {
			if (pre == cor)
				throw new IllegalStateException();
			if (cor == testa)
				testa = testa.next;
			else
				pre.next = cor.next;
			cor = pre;
		}// remove
	}// Iteratore

	public String toString() {

		StringBuilder sb = new StringBuilder(100);
		sb.append(" ");
		if (this != null) {
			sb.append('[');
			Node p = testa;
			while (p != null) {
				sb.append(p.info);
				p = p.next;
				if (p != null) {
					sb.append(',');
					sb.append(' ');
				}
			}
			sb.append("] (" + this.length + ")");
		}
		return sb.toString();
	}// toString

	public String toStringIT() {
		StringBuilder sb = new StringBuilder(100);
		sb.append('[');
		Iterator<Boolean> it = this.iterator();
		while (it.hasNext()) {
			sb.append(it.next());
			if (it.hasNext()) {
				sb.append(',');
				sb.append(' ');
			}
		}
		sb.append(']');
		return sb.toString();
	}// toString

	public int countMatch(boolean[] expl, int begin) {

		int count = 0;
		int indice = begin;

		Node corrente = testa;

		while (corrente != null) {
			// System.out.println(valore_corrente + "==" + e[indice]);
			if (corrente.info != expl[indice])
				return -1; // trovato valore diverso
			count++;
			corrente = corrente.next;
			indice++;
		}
		return count;
	}

	/**
	 * se restituisco null non devo splittare
	 * 
	 * @param expl
	 * @return
	 */
	public SplitTrie confronta(boolean[] expl, int start) {

		int index = start;
		Node prev = null;
		Node curr = testa;
		while (curr != null) {
			// System.out.println(valore_corrente + "==" + e[indice]);
			if (curr.info != expl[index]) {

				if (prev == null) {
					// � diverso gia il primo elemento
					return null;
				}

				prev.next = null;
				int new_length = length - (index - start);
				Node new_coda = coda;
				coda = prev;
				length = index - start;

				// in questo caso bisogna splittare. In split albero passiamo
				// l'elemento figlio e l'indice da cui dobbiamo andare a copiare
				// l'altro pezzo. 
				return new SplitTrie(new ListConcatenata(curr, new_coda,
						new_length), index);
			}// trovato valore dicerso

			prev = curr;
			curr = curr.next;
			index++;
		}

		// System.out.println("#pattern: " + num_pattern );

		
		//quando arriviamo qui significa che non dobbiamo splittare
		return new SplitTrie(null, index);

	}

	public static String stampaArray(int[] explanation) {

		StringBuilder sb = new StringBuilder();

		sb.append("[ ");
		for (int i = 0; i < explanation.length; i++) {
			sb.append(explanation[i] + " ");
		}
		sb.append("]");
		return sb.toString();
	}

	public ListConcatenata addExpl(boolean[] expl, int inizio, int fine) {

		for (int i = inizio; i < fine; i++)
			this.add(expl[i]);

		return this;

	}

	public static void main(String[] args) {
		ListConcatenata lc = new ListConcatenata();
		int[] expl = { 1 };
		boolean[] ex = new boolean[expl.length];
		for (int i = 0; i < ex.length; i++) {
			if (expl[i] == 1)
				ex[i] = true;
		}

		lc.addExpl(ex);
		boolean[] e = { false, false, false, true, false, false };
		System.out.println(lc.confronta(e, 0));
		// System.out.println(lc.cardinalita());
		//
		//
		// System.out.println(lc);
		// // System.out.println(lc.getTesta());

		// int[] e = { 0,0, 0,1,0,0 };
		// System.out.println(lc.contaMatch(e));

	}

}
