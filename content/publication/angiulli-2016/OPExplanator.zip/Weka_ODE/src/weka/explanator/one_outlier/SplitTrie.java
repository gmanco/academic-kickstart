package weka.explanator.one_outlier;

public class SplitTrie  {
	
	private ListConcatenata figlio;
	private int indice;

	public SplitTrie(ListConcatenata figlio, int indice) {
		this.figlio=figlio;
		this.indice=indice;
	}
	
	public int getIndice() {
		return indice;
	}
	
		public ListConcatenata getListaFiglio() {
		return figlio;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "[" + figlio.toString() + "- indice: " + indice + "]";
	}
	

}
