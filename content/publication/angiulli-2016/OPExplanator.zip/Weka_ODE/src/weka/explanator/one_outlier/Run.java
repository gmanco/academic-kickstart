package weka.explanator.one_outlier;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class Run {
	public static void main(String[] args) throws Exception {
		System.out.println("RUN");

		int id_out = 0;
		double threshold = 0;
		double omega = 0;
		int k = 0;
		int levels = 0;
		boolean tecnica = false;

		OPD_Depth_Main op;

		// OPD_Apriori_TRIE op;

		String elenco = "elenco_run_2";
		BufferedReader br = new BufferedReader(new FileReader(elenco));

		String text;

		StringTokenizer st;
		String nomeCartellaDestinazione = null;

		while ((text = br.readLine()) != null) {

			st = new StringTokenizer(text);
			// cartella res
			// idOut 7
			// levels 3
			// threshold 0.6
			// k 5
			// omega 0.2
			// tecnica topk

			while (st.hasMoreElements()) {
				String s1 = st.nextToken();
				if (s1.equals("cartella")) {
					String s2 = st.nextToken();
					nomeCartellaDestinazione = s2;
				} else if (s1.equals("EOF")) {
					break;
				} else if (s1.equals("idOut")) {
					id_out = Integer.parseInt(st.nextToken());
				} else if (s1.equals("levels")) {
					levels = Integer.parseInt(st.nextToken());
				} else if (s1.equals("threshold")) {
					threshold = Double.parseDouble(st.nextToken());
				} else if (s1.equals("k")) {
					k = Integer.parseInt(st.nextToken());
				} else if (s1.equals("omega")) {
					omega = Double.parseDouble(st.nextToken());
				} else if (s1.equals("tecnica")) {
					String s2 = st.nextToken();
					if (s2.equals("topk"))
						tecnica = false;
					else
						tecnica = true;
				} else {

					tecnica = false;

					System.out.println("Id out: " + id_out + " - Threshold: "
							+ threshold + " - Omega: " + omega + " - k: " + k
							+ " - levels: " + levels + " - " + tecnica);
					String file_ds = s1;
					String file_cl = st.nextToken();

					op = new OPD_Depth_Main(file_ds, file_cl, false, id_out,
							levels, k, omega, tecnica, threshold);

					// op = new OPD_Apriori_TRIE(file_ds, file_cl, false,
					// id_out, levels, k, omega, tecnica, threshold);
					String r_topk = op.toString();

					tecnica = true;

					// op = new OPD_Apriori_TRIE(file_ds, file_cl, false,
					// id_out, levels, k, omega, tecnica, threshold);

					op = new OPD_Depth_Main(file_ds, file_cl, false, id_out,
							levels, k, omega, tecnica, threshold);

					String r_omega = op.toString();

					PrintWriter p = new PrintWriter(nomeCartellaDestinazione
							+ "/" + file_ds + "_Result.txt");
					p.print(r_topk + "\n\n");
					p.print(r_omega + "\n\n");
					p.close();

				}

			}

			// buffer.append(text + "\n");
		}
		br.close();

	}

}
